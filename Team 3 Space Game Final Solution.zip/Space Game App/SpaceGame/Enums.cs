﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SpaceGame
{
    public enum PlayerTypes
    {
        Trader = 1,
        Entrepreneur,
        BountyHunter,
        Miner
    }

    public class Validation
    {
        
    }
}

