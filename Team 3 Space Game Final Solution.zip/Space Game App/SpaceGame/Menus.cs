﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SpaceGame
{
    public class Menus
    {
        //Methods with functionality of the game
        public void MainMenu(Player player, Menus main)
        {
            UserStatsDisplay(player);
            MainMenuDisplay(player, main);
        }

        public void TravelMenu(Player player, Menus main)
        {
            int selection = TravelMenuDisplay(player, main);
            Planets planet = new Planets();
            switch (selection)
            {
                case 1:
                    Venus venus = new Venus();
                    planet = venus;
                    main.UserStatsDisplay(player);
                    EnemyEncounterMenu(player, main);
                    DisplayVenus();
                    PlanetMenu(player, planet, main);
                    break;
                case 2:
                    Mars mars = new Mars();
                    planet = mars;
                    main.UserStatsDisplay(player);
                    EnemyEncounterMenu(player, main);
                    DisplayMars();
                    PlanetMenu(player, planet, main);
                    break;
                case 3:
                    Earth earth = new Earth();
                    planet = earth;
                    main.UserStatsDisplay(player);
                    EnemyEncounterMenu(player, main);
                    DisplayEarth();
                    PlanetMenu(player, planet, main);
                    break;
                case 4:
                    Mercury mercury = new Mercury();
                    planet = mercury;
                    main.UserStatsDisplay(player);
                    EnemyEncounterMenu(player, main);
                    DisplayMercury();
                    PlanetMenu(player, planet, main);
                    break;
                case 5:
                    Pluto pluto = new Pluto();
                    planet = pluto;
                    main.UserStatsDisplay(player);
                    EnemyEncounterMenu(player, main);
                    DisplayPluto();
                    PlanetMenu(player, planet, main);
                    break;
                case 6:
                    main.UserStatsDisplay(player);
                    EnemyEncounterMenu(player, main);
                    AsteroidMining(player, main);
                    break;
                case 7:
                    ClearMainViewer();
                    Enemies enemies = new Enemies();
                    enemies.hp = enemies.HPGenerator();
                    enemies.credits = enemies.CreditsGenerator();
                    enemies.attackPower = enemies.AttackGenerator();
                    Random findChance = new Random();
                    int chance = Convert.ToInt32(findChance.Next(0, 100));


                    if (chance >= 0 && chance <= 25)
                    {
                        enemies.name = new Sith().name;
                    }
                    else if (chance > 25 && chance <= 50)
                    {
                        enemies.name = new Romulan().name;
                    }
                    else if (chance > 50 && chance <= 75)
                    {
                        enemies.name = new GrayAlien().name;
                    }
                    else if (chance > 75 && chance <= 100)
                    {
                        enemies.name = new Pirates().name;
                    }
                    ClearMainViewer();
                    Console.SetCursorPosition(24, 6);
                    Console.Write($"During your travels, you have encountered a {enemies.name} with {enemies.hp} ship durability!!");
                    main.UserStatsDisplay(player);
                    FightSequence(player, main, enemies);
                    TravelMenu(player, main);
                    break;
                case 8:
                    main.UserStatsDisplay(player);
                    ClearMainViewer();
                    LenoreEncounter(player, main);
                    ClearMainViewer();
                    Console.SetCursorPosition(24, 14);
                    Console.Write($"You are now the new Programming Master!");
                    Console.SetCursorPosition(24, 15);
                    Console.Write($"You have defeated Lenore the Almighty Programming Boss!!!");
                    Console.SetCursorPosition(24, 17);
                    Console.Write("           You have won the game, CONGRATULATIONS!!!!!");
                    Console.SetCursorPosition(24, 19);
                    Console.Write("Please press <ENTER> to exit the game");
                    Console.ReadLine();
                    Environment.Exit(0);
                    break;
                case 9:
                    main.UserStatsDisplay(player);
                    MainMenu(player, main);
                    break;
                default:
                    break;
            }
        }

        public void PlanetMenu(Player player, Planets planet, Menus main)
        {
            int selection = PlanetMenuDisplay(player, planet, main);
            switch (selection)
            {
                case 1:
                    SellGoodsMenu(player, planet, main);
                    break;
                case 2:
                    ShipUpgradeMenu(player, planet, main);
                    break;
                case 3:
                    TravelMenu(player, main);
                    break;
            }
        }

        public void SellGoodsMenu(Player player, Planets planet, Menus main)
        {
            
            int selection = SellGoodsMenuDisplay(player, planet, main);
            switch (selection)
            {
                case 1:
                    ClearMainViewer();
                    ClearInputViewer();
                    Console.SetCursorPosition(24, 5);
                    Console.Write("                                                                            ");
                    Console.SetCursorPosition(24, 6);
                    Console.Write("                                                                            ");
                    Console.SetCursorPosition(24, 7);
                    Console.Write($"You have {player.playerCopper} units of copper to sell.");
                    Console.SetCursorPosition(24, 8);
                    Console.Write("                                                                            ");
                    Console.SetCursorPosition(24, 9);
                    Console.Write($"{planet.name} buys copper for {planet.copperValue} credits per unit.");
                    Console.SetCursorPosition(24, 10);
                    Console.Write("                                                                            ");
                    ClearMenuScreen();
                    Console.SetCursorPosition(127, 5);
                    Console.Write("1. Sell Goods              ");
                    Console.SetCursorPosition(127, 6);
                    Console.Write("                           ");
                    Console.SetCursorPosition(127, 7);
                    Console.Write("2. Return to Planet Menu   ");
                    Console.SetCursorPosition(127, 8);
                    Console.SetCursorPosition(24, 37);
                    Console.Write("Please select a numeric option from your Menu Display: ");
                    string inputsell = Console.ReadLine();
                    int selectionsell = player.InputValidation(inputsell, 1, 2);
                    if (selectionsell == 1)
                    {
                        int sellValue = (player.playerCopper * planet.copperValue);
                        ClearInputViewer();
                        Console.SetCursorPosition(24, 37);
                        Console.Write($"Do you want to sell your copper for {sellValue} credits? (1 for YES, 2 for NO): ");
                        string sellConfirm = Console.ReadLine();
                        int selectionsellConfirm = player.InputValidation(sellConfirm, 1, 2);
                        if (selectionsellConfirm == 1)
                        {
                            ClearInputViewer();
                            Console.SetCursorPosition(24, 37);
                            Console.Write($"You sold copper for {sellValue} Credits!");
                            player.playerCredits += sellValue;
                            player.playerCopper = 0;
                            player.playerEmptyCargoSpace = (player.playerShipCargoSpace - player.playerCopper - player.playerIronOre - player.playerGold - player.playerPlatinum - player.playerDiamonds);
                            main.UserStatsDisplay(player);
                            SellGoodsMenu(player, planet, main);
                        }
                        else
                        {
                            SellGoodsMenu(player, planet, main);
                        }
                    }
                    else
                    {
                        PlanetMenu(player, planet, main);
                    }
                    break;
                case 2:
                    ClearMainViewer();
                    ClearInputViewer();
                    Console.SetCursorPosition(24, 5);
                    Console.Write("                                                                            ");
                    Console.SetCursorPosition(24, 6);
                    Console.Write("                                                                            ");
                    Console.SetCursorPosition(24, 7);
                    Console.Write($"You have {player.playerGold} units of gold to sell.");
                    Console.SetCursorPosition(24, 8);
                    Console.Write("                                                                            ");
                    Console.SetCursorPosition(24, 9);
                    Console.Write($"{planet.name} buys gold for {planet.goldValue} credits per unit.");
                    Console.SetCursorPosition(24, 10);
                    Console.Write("                                                                            ");
                    ClearMenuScreen();
                    Console.SetCursorPosition(127, 5);
                    Console.Write("1. Sell Goods              ");
                    Console.SetCursorPosition(127, 6);
                    Console.Write("                           ");
                    Console.SetCursorPosition(127, 7);
                    Console.Write("2. Return to Planet Menu   ");
                    Console.SetCursorPosition(127, 8);
                    Console.SetCursorPosition(24, 37);
                    Console.Write("Please select a numeric option from your Menu Display: ");
                    string inputsellGold = Console.ReadLine();
                    int selectionsellGold = player.InputValidation(inputsellGold, 1, 2);
                    if (selectionsellGold == 1)
                    {
                        int sellValue = (player.playerGold * planet.goldValue);
                        ClearInputViewer();
                        Console.SetCursorPosition(24, 37);
                        Console.Write($"Do you want to sell your gold for {sellValue} credits? (1 for YES, 2 for NO): ");
                        string sellConfirm = Console.ReadLine();
                        int selectionsellConfirm = player.InputValidation(sellConfirm, 1, 2);
                        if (selectionsellConfirm == 1)
                        {
                            ClearInputViewer();
                            Console.SetCursorPosition(24, 37);
                            Console.Write($"You sold gold for {sellValue} Credits!");
                            player.playerCredits += sellValue;
                            player.playerGold = 0;
                            player.playerEmptyCargoSpace = (player.playerShipCargoSpace - player.playerCopper - player.playerIronOre - player.playerGold - player.playerPlatinum - player.playerDiamonds);
                            main.UserStatsDisplay(player);
                            SellGoodsMenu(player, planet, main);
                        }
                        else
                        {
                            SellGoodsMenu(player, planet, main);
                        }
                    }
                    else
                    {
                        PlanetMenu(player, planet, main);
                    }
                    break;
                case 3:
                    ClearMainViewer();
                    ClearInputViewer();
                    Console.SetCursorPosition(24, 5);
                    Console.Write("                                                                            ");
                    Console.SetCursorPosition(24, 6);
                    Console.Write("                                                                            ");
                    Console.SetCursorPosition(24, 7);
                    Console.Write($"You have {player.playerPlatinum} units of platinum to sell.");
                    Console.SetCursorPosition(24, 8);
                    Console.Write("                                                                            ");
                    Console.SetCursorPosition(24, 9);
                    Console.Write($"{planet.name} buys platinum for {planet.platinumValue} credits per unit.");
                    Console.SetCursorPosition(24, 10);
                    Console.Write("                                                                            ");
                    ClearMenuScreen();
                    Console.SetCursorPosition(127, 5);
                    Console.Write("1. Sell Goods              ");
                    Console.SetCursorPosition(127, 6);
                    Console.Write("                           ");
                    Console.SetCursorPosition(127, 7);
                    Console.Write("2. Return to Planet Menu   ");
                    Console.SetCursorPosition(127, 8);
                    Console.SetCursorPosition(24, 37);
                    Console.Write("Please select a numeric option from your Menu Display: ");
                    string inputsellPlatinum = Console.ReadLine();
                    int selectionsellPlatinum = player.InputValidation(inputsellPlatinum, 1, 2);
                    if (selectionsellPlatinum == 1)
                    {
                        int sellValue = (player.playerPlatinum * planet.platinumValue);
                        ClearInputViewer();
                        Console.SetCursorPosition(24, 37);
                        Console.Write($"Do you want to sell your platinum for {sellValue} credits? (1 for YES, 2 for NO): ");
                        string sellConfirm = Console.ReadLine();
                        int selectionsellConfirm = player.InputValidation(sellConfirm, 1, 2);
                        if (selectionsellConfirm == 1)
                        {
                            ClearInputViewer();
                            Console.SetCursorPosition(24, 37);
                            Console.Write($"You sold platinum for {sellValue} Credits!");
                            player.playerCredits += sellValue;
                            player.playerPlatinum = 0;
                            player.playerEmptyCargoSpace = (player.playerShipCargoSpace - player.playerCopper - player.playerIronOre - player.playerGold - player.playerPlatinum - player.playerDiamonds);
                            main.UserStatsDisplay(player);
                            SellGoodsMenu(player, planet, main);
                        }
                        else
                        {
                            SellGoodsMenu(player, planet, main);
                        }
                    }
                    else
                    {
                        PlanetMenu(player, planet, main);
                    }
                    break;
                case 4:
                    ClearMainViewer();
                    ClearInputViewer();
                    Console.SetCursorPosition(24, 5);
                    Console.Write("                                                                            ");
                    Console.SetCursorPosition(24, 6);
                    Console.Write("                                                                            ");
                    Console.SetCursorPosition(24, 7);
                    Console.Write($"You have {player.playerDiamonds} units of diamonds to sell.");
                    Console.SetCursorPosition(24, 8);
                    Console.Write("                                                                            ");
                    Console.SetCursorPosition(24, 9);
                    Console.Write($"{planet.name} buys diamonds for {planet.diamondValue} credits per unit.");
                    Console.SetCursorPosition(24, 10);
                    Console.Write("                                                                            ");
                    ClearMenuScreen();
                    Console.SetCursorPosition(127, 5);
                    Console.Write("1. Sell Goods              ");
                    Console.SetCursorPosition(127, 6);
                    Console.Write("                           ");
                    Console.SetCursorPosition(127, 7);
                    Console.Write("2. Return to Planet Menu   ");
                    Console.SetCursorPosition(127, 8);
                    Console.SetCursorPosition(24, 37);
                    Console.Write("Please select a numeric option from your Menu Display: ");
                    string inputSellDiamonds = Console.ReadLine();
                    int selectionsellDiamonds = player.InputValidation(inputSellDiamonds, 1, 2);
                    if (selectionsellDiamonds == 1)
                    {
                        int sellValue = (player.playerDiamonds * planet.diamondValue);
                        ClearInputViewer();
                        Console.SetCursorPosition(24, 37);
                        Console.Write($"Do you want to sell your diamonds for {sellValue} credits? (1 for YES, 2 for NO): ");
                        string sellConfirm = Console.ReadLine();
                        int selectionsellConfirm = player.InputValidation(sellConfirm, 1, 2);
                        if (selectionsellConfirm == 1)
                        {
                            ClearInputViewer();
                            Console.SetCursorPosition(24, 37);
                            Console.Write($"You sold diamonds for {sellValue} Credits!");
                            player.playerCredits += sellValue;
                            player.playerDiamonds = 0;
                            player.playerEmptyCargoSpace = (player.playerShipCargoSpace - player.playerCopper - player.playerIronOre - player.playerGold - player.playerPlatinum - player.playerDiamonds);
                            main.UserStatsDisplay(player);
                            SellGoodsMenu(player, planet, main);
                        }
                        else
                        {
                            SellGoodsMenu(player, planet, main);
                        }
                    }
                    else
                    {
                        PlanetMenu(player, planet, main);
                    }
                    break;
                case 5:
                    ClearMainViewer();
                    ClearInputViewer();
                    Console.SetCursorPosition(24, 5);
                    Console.Write("                                                                            ");
                    Console.SetCursorPosition(24, 6);
                    Console.Write("                                                                            ");
                    Console.SetCursorPosition(24, 7);
                    Console.Write($"You have {player.playerIronOre} units of iron-ore to sell.");
                    Console.SetCursorPosition(24, 8);
                    Console.Write("                                                                            ");
                    Console.SetCursorPosition(24, 9);
                    Console.Write($"{planet.name} buys iron-ore for {planet.ironValue} credits per unit.");
                    Console.SetCursorPosition(24, 10);
                    Console.Write("                                                                            ");
                    ClearMenuScreen();
                    Console.SetCursorPosition(127, 5);
                    Console.Write("1. Sell Goods              ");
                    Console.SetCursorPosition(127, 6);
                    Console.Write("                           ");
                    Console.SetCursorPosition(127, 7);
                    Console.Write("2. Return to Planet Menu   ");
                    Console.SetCursorPosition(127, 8);
                    Console.SetCursorPosition(24, 37);
                    Console.Write("Please select a numeric option from your Menu Display: ");
                    string inputsellIronOre = Console.ReadLine();
                    int selectionsellIronOre = player.InputValidation(inputsellIronOre, 1, 2);
                    if (selectionsellIronOre == 1)
                    {
                        int sellValue = (player.playerIronOre * planet.ironValue);
                        ClearInputViewer();
                        Console.SetCursorPosition(24, 37);
                        Console.Write($"Do you want to sell your Iron for {sellValue} credits? (1 for YES, 2 for NO): ");
                        string sellConfirm = Console.ReadLine();
                        int selectionsellConfirm = player.InputValidation(sellConfirm, 1, 2);
                        if (selectionsellConfirm == 1)
                        {
                            ClearInputViewer();
                            Console.SetCursorPosition(24, 37);
                            Console.Write($"You sold Iron for {sellValue} Credits!");
                            player.playerCredits += sellValue;
                            player.playerIronOre = 0;
                            player.playerEmptyCargoSpace = (player.playerShipCargoSpace - player.playerCopper - player.playerIronOre - player.playerGold - player.playerPlatinum - player.playerDiamonds);
                            main.UserStatsDisplay(player);
                            SellGoodsMenu(player, planet, main);
                        }
                        else
                        {
                            SellGoodsMenu(player, planet, main);
                        }
                    }
                    else
                    {
                        PlanetMenu(player, planet, main);
                    }
                    break;
                case 6:
                    PlanetMenu(player, planet, main);
                    break;
            }
        }

        public void ShipUpgradeMenu(Player player, Planets planet, Menus main)
        {
            
            int selection = ShipUgradeDisplay(player, main);
            switch (selection)
            {
                case 1: //cargo upgrade
                    ClearMenuScreen();
                    Console.SetCursorPosition(127, 5);
                    Console.Write("1. Upgrade Cargo Space     ");
                    Console.SetCursorPosition(127, 6);
                    Console.Write("                           ");
                    Console.SetCursorPosition(127, 7);
                    Console.Write("2. Return to Upgrade Menu  ");
                    ClearInputViewer();
                    Console.SetCursorPosition(24, 37);
                    Console.Write("Please select a numeric option from your Menu Display: ");
                    string choicecargoString = Console.ReadLine();
                    int choicecargo = player.InputValidation(choicecargoString, 1, 2);
                    if (choicecargo == 1)
                    {
                        if (player.playerCredits >= 1000)
                        {
                            player.playerShipCargoSpace += 5;
                            player.playerEmptyCargoSpace += 5;
                            ClearInputViewer();
                            Console.SetCursorPosition(24, 37);
                            Console.Write($"Your cargo space has been upgraded to {player.playerShipCargoSpace}.");
                            Console.SetCursorPosition(24, 39);
                            Console.Write($"Press <ENTER> to continue...");
                            Console.ReadLine();
                            player.playerCredits -= 1000;
                            main.UserStatsDisplay(player);
                            ShipUpgradeMenu(player, planet, main);
                        }
                        else
                        {
                            ClearInputViewer();
                            Console.SetCursorPosition(24, 37);
                            Console.Write("You dont have enough credits...<ENTER> to continue");
                            Console.ReadLine();
                            ShipUpgradeMenu(player, planet, main);
                        }
                    }
                    ShipUpgradeMenu(player, planet, main);
                    break;
                case 2: //scanner upgrade
                    ClearMenuScreen();
                    Console.SetCursorPosition(127, 5);
                    Console.Write("1. Upgrade Ship Scanner    ");
                    Console.SetCursorPosition(127, 6);
                    Console.Write("                           ");
                    Console.SetCursorPosition(127, 7);
                    Console.Write("2. Return to Upgrade Menu  ");
                    ClearInputViewer();
                    Console.SetCursorPosition(24, 37);
                    Console.Write("Please select a numeric option from your Menu Display: ");
                    string choicescannerString = Console.ReadLine();
                    int choiceScanner = player.InputValidation(choicescannerString, 1, 2);
                    if (choiceScanner == 1)
                    {
                        if (player.playerCredits >= 1100 && player.playerScannerLevel == 0)
                        {
                            player.playerScannerLevel += 10;
                            ClearInputViewer();
                            Console.SetCursorPosition(24, 37);
                            Console.Write($"Your scanner has been upgraded!");
                            Console.SetCursorPosition(24, 39);
                            Console.Write($"Press <ENTER> to continue...");
                            Console.ReadLine();
                            player.playerCredits -= 1100;
                            main.UserStatsDisplay(player);
                            ShipUpgradeMenu(player, planet, main);

                        }
                        if (player.playerCredits >= ((player.playerScannerLevel * 1100 / 10)) && player.playerScannerLevel < 80)
                        {
                            
                            ClearInputViewer();
                            Console.SetCursorPosition(24, 37);
                            Console.Write($"Your scanner has been upgraded!");
                            Console.SetCursorPosition(24, 39);
                            Console.Write($"Press <ENTER> to continue...");
                            Console.ReadLine();
                            player.playerCredits -= (player.playerScannerLevel * 1100 / 10);
                            player.playerScannerLevel += 10;
                            main.UserStatsDisplay(player);
                            ShipUpgradeMenu(player, planet, main);
                        }
                        else
                        {
                            ClearInputViewer();
                            Console.SetCursorPosition(24, 37);
                            Console.Write("You dont have the credits to upgrade your scanner ");
                            Console.SetCursorPosition(24, 38);
                            Console.Write($"or you have a level 8 scanner...");
                            Console.SetCursorPosition(24, 39);
                            Console.Write($"Press <ENTER> to continue...");
                            Console.ReadLine();
                            ShipUpgradeMenu(player, planet, main);
                        }
                    }
                    ShipUpgradeMenu(player, planet, main);
                    break;
                case 3: //laser upgrade
                    ClearMenuScreen();
                    Console.SetCursorPosition(127, 5);
                    Console.Write("1.Upgrade Ship Mining Laser");
                    Console.SetCursorPosition(127, 6);
                    Console.Write("                           ");
                    Console.SetCursorPosition(127, 7);
                    Console.Write("2. Return to Upgrade Menu  ");
                    ClearInputViewer();
                    Console.SetCursorPosition(24, 37);
                    Console.Write("Please select a numeric option from your Menu Display: ");
                    string choiceLaserString = Console.ReadLine();
                    int choiceLaser = player.InputValidation(choiceLaserString, 1, 2);
                    if (choiceLaser == 1)
                    {
                        if (player.playerCredits >= 1500 && player.playerMiningLaserLevel == 0)
                        {
                            player.playerMiningLaserLevel += 1;
                            ClearInputViewer();
                            Console.SetCursorPosition(24, 37);
                            Console.Write($"Your Mining Laser has been upgraded!");
                            Console.SetCursorPosition(24, 39);
                            Console.Write($"Press <ENTER> to continue...");
                            Console.ReadLine();
                            player.playerCredits -= 1500;
                            main.UserStatsDisplay(player);
                            ShipUpgradeMenu(player, planet, main);
                        }
                        if (player.playerCredits >= (player.playerMiningLaserLevel * 1500) && player.playerMiningLaserLevel < 9)
                        {
                            
                            ClearInputViewer();
                            Console.SetCursorPosition(24, 37);
                            Console.Write($"Your Mining Laser has been upgraded!");
                            Console.SetCursorPosition(24, 39);
                            Console.Write($"Press <ENTER> to continue...");
                            Console.ReadLine();
                            player.playerCredits -= (player.playerMiningLaserLevel * 1500);
                            player.playerMiningLaserLevel += 1;
                            main.UserStatsDisplay(player);
                            ShipUpgradeMenu(player, planet, main);
                        }
                        else
                        {
                            ClearInputViewer();
                            Console.SetCursorPosition(24, 37);
                            Console.Write("You dont have the credits to upgrade you Mining Laser ");
                            Console.SetCursorPosition(24, 38);
                            Console.Write("or your Mining Laser is maximum level...");
                            Console.SetCursorPosition(24, 39);
                            Console.Write($"Press <ENTER> to continue...");
                            Console.ReadLine();
                            ShipUpgradeMenu(player, planet, main);
                        }
                    }
                    ShipUpgradeMenu(player, planet, main);
                    break;
                case 4:  //weapons upgrade
                    ClearMenuScreen();
                    Console.SetCursorPosition(127, 5);
                    Console.Write("1. Upgrade Ship Weapons");
                    Console.SetCursorPosition(127, 6);
                    Console.Write("                           ");
                    Console.SetCursorPosition(127, 7);
                    Console.Write("2. Return to Upgrade Menu  ");
                    ClearInputViewer();
                    Console.SetCursorPosition(24, 37);
                    Console.Write("Please select a numeric option from your Menu Display: ");
                    string choiceWeaponString = Console.ReadLine();
                    int choiceWeapon = player.InputValidation(choiceWeaponString, 1, 2);
                    if (choiceWeapon == 1)
                    {
                        if (player.playerCredits >= 2000 && player.playerWeaponLevel == 0)
                        {
                            player.playerWeaponLevel += 1;
                            ClearInputViewer();
                            Console.SetCursorPosition(24, 37);
                            Console.Write($"Your ship weapons have been upgraded!");
                            Console.SetCursorPosition(24, 39);
                            Console.Write($"Press <ENTER> to continue...");
                            Console.ReadLine();
                            player.playerCredits -= 2000;
                            main.UserStatsDisplay(player);
                            ShipUpgradeMenu(player, planet, main);

                        }
                        if (player.playerCredits >= (player.playerWeaponLevel * 2000) && player.playerWeaponLevel > 0)
                        {
                            ClearInputViewer();
                            Console.SetCursorPosition(24, 37);
                            Console.Write($"Your ship weapons have been upgraded!");
                            Console.SetCursorPosition(24, 39);
                            Console.Write($"Press <ENTER> to continue...");
                            Console.ReadLine();
                            player.playerCredits -= (player.playerWeaponLevel * 2000);
                            player.playerWeaponLevel += 1;
                            main.UserStatsDisplay(player);
                            ShipUpgradeMenu(player, planet, main);
                        }
                        else
                        {
                            ClearInputViewer();
                            Console.SetCursorPosition(24, 37);
                            Console.Write("You dont have the credits to upgrade you ship weapons...");
                            Console.SetCursorPosition(24, 39);
                            Console.Write($"Press <ENTER> to continue...");
                            Console.ReadLine();
                            ShipUpgradeMenu(player, planet, main);
                        }
                    }
                    ShipUpgradeMenu(player, planet, main);
                    break;
                case 5: //armor upgrade
                    ClearMenuScreen();
                    Console.SetCursorPosition(127, 5);
                    Console.Write("1. Upgrade Ship Armor      ");
                    Console.SetCursorPosition(127, 6);
                    Console.Write("                           ");
                    Console.SetCursorPosition(127, 7);
                    Console.Write("2. Return to Upgrade Menu  ");
                    ClearInputViewer();
                    Console.SetCursorPosition(24, 37);
                    Console.Write("Please select a numeric option from your Menu Display: ");
                    string choiceArmorString = Console.ReadLine();
                    int choiceArmor = player.InputValidation(choiceArmorString, 1, 2);
                    if (choiceArmor == 1)
                    {
                        if (player.playerCredits >= 1000)
                        {
                            player.shipMaxDurability += 20;
                            player.shipDurability += 20;
                            ClearInputViewer();
                            Console.SetCursorPosition(24, 37);
                            Console.Write($"Your ship's armor has been upgraded to {player.shipMaxDurability}.");
                            Console.SetCursorPosition(24, 39);
                            Console.Write($"Press <ENTER> to continue...");
                            Console.ReadLine();
                            player.playerCredits -= 1000;
                            main.UserStatsDisplay(player);
                            ShipUpgradeMenu(player, planet, main);
                        }
                        else
                        {
                            ClearInputViewer();
                            Console.SetCursorPosition(24, 37);
                            Console.Write("You dont have enough credits...<ENTER> to continue");
                            Console.ReadLine();
                            ShipUpgradeMenu(player, planet, main);
                        }
                    }
                    ShipUpgradeMenu(player, planet, main);
                    break;
                case 6: //ship repair
                    ClearMenuScreen();
                    Console.SetCursorPosition(127, 5);
                    Console.Write("1. Repair Your Ship");
                    Console.SetCursorPosition(127, 6);
                    Console.Write("                           ");
                    Console.SetCursorPosition(127, 7);
                    Console.Write("2. Return to Upgrade Menu  ");
                    ClearInputViewer();
                    Console.SetCursorPosition(24, 37);
                    Console.Write($"It will cost {(player.shipMaxDurability - player.shipDurability) * 4}");
                    Console.SetCursorPosition(24, 38);
                    Console.Write($"credits to repair your ship.  Shall we proceed? (1 for YES, 2 for NO): ");
                    string choiceDurString = Console.ReadLine();
                    int choiceDur = player.InputValidation(choiceDurString, 1, 2);
                    if (choiceDur == 1)
                    {
                        if (player.playerCredits >= (player.shipMaxDurability - player.shipDurability) * 4)
                        {
                            ClearInputViewer();
                            Console.SetCursorPosition(24, 37);
                            Console.Write("Your ship has been repaired!");
                            Console.SetCursorPosition(24, 39);
                            Console.Write($"Press <ENTER> to continue...");
                            Console.ReadLine();
                            player.playerCredits -= ((player.shipMaxDurability - player.shipDurability) * 4);
                            player.shipDurability = player.shipMaxDurability;
                            main.UserStatsDisplay(player);
                        }
                        else
                        {
                            ClearInputViewer();
                            Console.SetCursorPosition(24, 37);
                            Console.Write("You dont have the credits to repair your ship...");
                            Console.SetCursorPosition(24, 39);
                            Console.Write($"Press <ENTER> to continue...");
                            Console.ReadLine();
                            ShipUpgradeMenu(player, planet, main);
                        }
                    }
                    ShipUpgradeMenu(player, planet, main);
                    break;
                case 7:
                    PlanetMenu(player, planet, main);
                break;
                 }
        }
        
        public void AsteroidMining(Player player, Menus main)
        {
            main.UserStatsDisplay(player);
            player.playerEmptyCargoSpace = (player.playerShipCargoSpace - player.playerCopper - player.playerIronOre - player.playerGold - player.playerPlatinum - player.playerDiamonds);
            int copper, gold, platinum, diamonds, ironOre;
            int mineralPicked = main.AsteroidMiningDisplay(player, main);
            int chance;
            Random findChance = new Random();
            Random foundAmount = new Random();
            switch (mineralPicked)
            {
                case 1: //Chance to find Copper
                    if (player.playerCredits >= 200) //Check to see if user has credits to scan
                    {
                        player.playerCredits -= 200;
                        chance = findChance.Next(0, 100); //Random for scan success
                        if (chance > (80 - player.playerScannerLevel)) //each scanner level = 10
                        {
                            copper = foundAmount.Next(1 + (player.playerMiningLaserLevel * 2), 21); //eac mining laser level = 1
                            if (player.playerEmptyCargoSpace == 0)
                            {
                                Console.SetCursorPosition(24, 6);
                                Console.Write("                                                                            ");
                                Console.SetCursorPosition(24, 6);
                                Console.Write("You don't have any empty cargo space on your ship!");
                                ClearInputViewer();
                                Console.SetCursorPosition(24, 37);
                                Console.Write("Please select a numeric option from your Menu Display: ");
                                main.UserStatsDisplay(player);
                                TravelMenu(player, main);
                            }
                            if (copper > player.playerEmptyCargoSpace)  //Check to see if found amount is more than empty cargo space
                            {
                                Console.SetCursorPosition(24, 6);
                                Console.Write("                                                                            ");
                                Console.SetCursorPosition(24, 6);
                                Console.Write($"You found {copper} copper units, but you only have space for ");
                                Console.SetCursorPosition(24, 7);
                                Console.Write("                                                                            ");
                                Console.SetCursorPosition(24, 7);
                                Console.Write($"{player.playerEmptyCargoSpace} units in your ship.");
                                copper = player.playerEmptyCargoSpace;
                                player.playerCopper += copper;
                                player.playerEmptyCargoSpace = (player.playerShipCargoSpace - player.playerCopper - player.playerIronOre - player.playerGold - player.playerPlatinum - player.playerDiamonds);
                                main.UserStatsDisplay(player);
                                TravelMenu(player, main);
                            }
                            else
                            {
                                Console.SetCursorPosition(24, 6);
                                Console.Write("                                                                            ");
                                Console.SetCursorPosition(24, 6);
                                Console.Write($"You were able to mine {copper} units of copper successfully!");
                                player.playerCopper += copper;
                                player.playerEmptyCargoSpace = (player.playerShipCargoSpace - player.playerCopper - player.playerIronOre - player.playerGold - player.playerPlatinum - player.playerDiamonds);
                                main.UserStatsDisplay(player);
                                ClearInputViewer();
                                TravelMenu(player, main);
                            }
                        }
                        else //Didn't find, but got ore
                        {
                            ironOre = foundAmount.Next(3 + (player.playerMiningLaserLevel * 2), 20);
                            if (player.playerEmptyCargoSpace == 0)
                            {
                                Console.SetCursorPosition(24, 6);
                                Console.Write("                                                                            ");
                                Console.SetCursorPosition(24, 6);
                                Console.Write("You don't have any empty cargo space on your ship!");
                                ClearInputViewer();
                                Console.SetCursorPosition(24, 37);
                                Console.Write("Please select a numeric option from your Menu Display: ");
                                main.UserStatsDisplay(player);
                                TravelMenu(player, main);
                            }
                            if (ironOre > player.playerEmptyCargoSpace)
                            {
                                Console.SetCursorPosition(24, 6);
                                Console.Write("                                                                            ");
                                Console.SetCursorPosition(24, 6);
                                Console.Write($"You found {ironOre} iron-ore units, but you only have space for");
                                Console.SetCursorPosition(24, 7);
                                Console.Write("                                                                            ");
                                Console.SetCursorPosition(24, 7);
                                Console.Write($"{ player.playerEmptyCargoSpace} units in your ship.");
                                ironOre = player.playerEmptyCargoSpace;
                                player.playerIronOre += ironOre;
                                player.playerEmptyCargoSpace = (player.playerShipCargoSpace - player.playerCopper - player.playerIronOre - player.playerGold - player.playerPlatinum - player.playerDiamonds);
                                main.UserStatsDisplay(player);
                                ClearInputViewer();
                                Console.SetCursorPosition(24, 37);
                                Console.Write("Please select a numeric option from your Menu Display: ");
                                TravelMenu(player, main);
                            }
                            if (ironOre < player.playerEmptyCargoSpace)
                            {
                                Console.SetCursorPosition(24, 6);
                                Console.Write("                                                                            ");
                                Console.SetCursorPosition(24, 6);
                                Console.Write($"You didn't find what you were looking for, but you did find {ironOre}");
                                Console.SetCursorPosition(24, 7);
                                Console.Write("                                                                            ");
                                Console.SetCursorPosition(24, 7);
                                Console.Write($"units of iron-ore...");
                                player.playerIronOre += ironOre;
                                player.playerEmptyCargoSpace = (player.playerShipCargoSpace - player.playerCopper - player.playerIronOre - player.playerGold - player.playerPlatinum - player.playerDiamonds);
                                main.UserStatsDisplay(player);
                                ClearInputViewer();
                                Console.SetCursorPosition(24, 37);
                                Console.Write("Please select a numeric option from your Menu Display: ");
                                TravelMenu(player, main);
                            }
                        }
                    }
                    else
                    {
                        Console.SetCursorPosition(24, 6);
                        Console.Write("                                                                            ");
                        Console.SetCursorPosition(24, 6);
                        Console.Write("Sorry, you don't have the required credits to scan for this!");
                        main.UserStatsDisplay(player);
                        ClearInputViewer();
                        TravelMenu(player, main);
                        Console.SetCursorPosition(24, 37);
                        Console.Write("Please select a numeric option from your Menu Display: ");
                    }
                    break;
                case 2: //Chance to find Gold
                    chance = findChance.Next(0, 100);
                    if (player.playerCredits >= 300) //Check to see if user has credits to scan
                    {
                        player.playerCredits -= 300;
                        chance = findChance.Next(0, 100); //Random for scan success
                        if (chance > (85 - player.playerScannerLevel)) //each scanner level = 10
                        {
                            gold = foundAmount.Next(1 + (player.playerMiningLaserLevel * 2), 21); //eac mining laser level = 1
                            if (player.playerEmptyCargoSpace == 0)
                            {
                                Console.SetCursorPosition(24, 6);
                                Console.Write("                                                                            ");
                                Console.SetCursorPosition(24, 6);
                                Console.Write("You don't have any empty cargo space on your ship!");
                                ClearInputViewer();
                                Console.SetCursorPosition(24, 37);
                                Console.Write("Please select a numeric option from your Menu Display: ");
                                main.UserStatsDisplay(player);
                                TravelMenu(player, main);
                            }
                            if (gold > player.playerEmptyCargoSpace)  //Check to see if found amount is more than empty cargo space
                            {
                                Console.SetCursorPosition(24, 6);
                                Console.Write("                                                                            ");
                                Console.SetCursorPosition(24, 6);
                                Console.WriteLine($"You found {gold} gold units, but you only have space for");
                                Console.SetCursorPosition(24, 7);
                                Console.Write("                                                                            ");
                                Console.SetCursorPosition(24, 7);
                                Console.Write($"{ player.playerEmptyCargoSpace} units in your ship.");
                                gold = player.playerEmptyCargoSpace;
                                player.playerGold += gold;
                                player.playerEmptyCargoSpace = (player.playerShipCargoSpace - player.playerCopper - player.playerIronOre - player.playerGold - player.playerPlatinum - player.playerDiamonds);
                                ClearInputViewer();
                                Console.SetCursorPosition(24, 37);
                                Console.Write("Please select a numeric option from your Menu Display: ");
                                main.UserStatsDisplay(player);
                            }

                            else
                            {
                                Console.SetCursorPosition(24, 6);
                                Console.Write("                                                                            ");
                                Console.SetCursorPosition(24, 6);
                                Console.Write($"You were able to mine {gold} units of gold successfully!");
                                player.playerGold += gold;
                                player.playerEmptyCargoSpace = (player.playerShipCargoSpace - player.playerCopper - player.playerIronOre - player.playerGold - player.playerPlatinum - player.playerDiamonds);
                                main.UserStatsDisplay(player);
                                ClearInputViewer();
                                Console.SetCursorPosition(24, 37);
                                Console.Write("Please select a numeric option from your Menu Display: ");
                                TravelMenu(player, main);
                            }
                        }
                        else //Didn't find, but got ore
                        {
                            ironOre = foundAmount.Next(3 + (player.playerMiningLaserLevel * 2), 20);
                            if (player.playerEmptyCargoSpace == 0)
                            {
                                Console.SetCursorPosition(24, 6);
                                Console.Write("                                                                            ");
                                Console.SetCursorPosition(24, 6);
                                Console.Write("You don't have any empty cargo space on your ship!");
                                main.UserStatsDisplay(player);
                                ClearInputViewer();
                                Console.SetCursorPosition(24, 37);
                                Console.Write("Please select a numeric option from your Menu Display: ");
                                TravelMenu(player, main);
                            }
                            if (ironOre > player.playerEmptyCargoSpace)
                            {
                                Console.SetCursorPosition(24, 6);
                                Console.Write("                                                                            ");
                                Console.SetCursorPosition(24, 6);
                                Console.Write($"You found {ironOre} iron-ore units, but you only have space for");
                                Console.SetCursorPosition(24, 7);
                                Console.Write("                                                                            ");
                                Console.SetCursorPosition(24, 7);
                                Console.Write($"{ player.playerEmptyCargoSpace} units in your ship.");
                                ironOre = player.playerEmptyCargoSpace;
                                player.playerIronOre += ironOre;
                                player.playerEmptyCargoSpace = (player.playerShipCargoSpace - player.playerCopper - player.playerIronOre - player.playerGold - player.playerPlatinum - player.playerDiamonds);
                                main.UserStatsDisplay(player);
                                ClearInputViewer();
                                Console.SetCursorPosition(24, 37);
                                Console.Write("Please select a numeric option from your Menu Display: ");
                                TravelMenu(player, main);
                            }
                            if (ironOre < player.playerEmptyCargoSpace)
                            {
                                Console.SetCursorPosition(24, 6);
                                Console.Write("                                                                            ");
                                Console.SetCursorPosition(24, 6);
                                Console.Write($"You didn't find what you were looking for, but you did find {ironOre}");
                                Console.SetCursorPosition(24, 7);
                                Console.Write("                                                                            ");
                                Console.SetCursorPosition(24, 7);
                                Console.Write($"units of iron-ore...");
                                player.playerIronOre += ironOre;
                                player.playerEmptyCargoSpace = (player.playerShipCargoSpace - player.playerCopper - player.playerIronOre - player.playerGold - player.playerPlatinum - player.playerDiamonds);
                                main.UserStatsDisplay(player);
                                ClearInputViewer();
                                Console.SetCursorPosition(24, 37);
                                Console.Write("Please select a numeric option from your Menu Display: ");
                                TravelMenu(player, main);
                            }
                        }
                    }
                    else
                    {
                        Console.SetCursorPosition(24, 6);
                        Console.Write("                                                                            ");
                        Console.SetCursorPosition(24, 6);
                        Console.Write("Sorry, you don't have the required credits to scan for this!"); 
                        main.UserStatsDisplay(player);
                        ClearInputViewer();
                        TravelMenu(player, main);
                        Console.SetCursorPosition(24, 37);
                        Console.Write("Please select a numeric option from your Menu Display: ");
                    }
                    break;
                case 3: //Chance to find Platinum 
                    if (player.playerCredits >= 400) //Check to see if user has credits to scan
                    {
                        player.playerCredits -= 400;
                        chance = findChance.Next(0, 100); //Random for scan success
                        if (chance > (90 - player.playerScannerLevel)) //each scanner level = 10
                        {
                            platinum = foundAmount.Next(1 + (player.playerMiningLaserLevel * 2), 21); //eac mining laser level = 1
                            if (player.playerEmptyCargoSpace == 0)
                            {
                                Console.SetCursorPosition(24, 6);
                                Console.Write("                                                                            ");
                                Console.SetCursorPosition(24, 6);
                                Console.Write("You don't have any empty cargo space on your ship!");
                                main.UserStatsDisplay(player);
                                ClearInputViewer();
                                Console.SetCursorPosition(24, 37);
                                Console.Write("Please select a numeric option from your Menu Display: ");
                                TravelMenu(player, main);
                            }
                            if (platinum > player.playerEmptyCargoSpace)  //Check to see if found amount is more than empty cargo space
                            {
                                Console.SetCursorPosition(24, 6);
                                Console.Write("                                                                            ");
                                Console.SetCursorPosition(24, 6);
                                Console.Write($"You found {platinum} platinum units, but you only have space for ");
                                Console.SetCursorPosition(24, 7);
                                Console.Write("                                                                            ");
                                Console.SetCursorPosition(24, 7);
                                Console.Write($"{ player.playerEmptyCargoSpace} units in your ship.");
                                platinum = player.playerEmptyCargoSpace;
                                player.playerPlatinum += platinum;
                                player.playerEmptyCargoSpace = (player.playerShipCargoSpace - player.playerCopper - player.playerIronOre - player.playerGold - player.playerPlatinum - player.playerDiamonds);
                                ClearInputViewer();
                                Console.SetCursorPosition(24, 37);
                                Console.Write("Please select a numeric option from your Menu Display: ");
                                main.UserStatsDisplay(player);
                            }

                            else
                            {
                                Console.SetCursorPosition(24, 6);
                                Console.Write("                                                                            ");
                                Console.SetCursorPosition(24, 6);
                                Console.Write($"You were able to mine {platinum} units of platinum successfully!");
                                player.playerPlatinum += platinum;
                                player.playerEmptyCargoSpace = (player.playerShipCargoSpace - player.playerCopper - player.playerIronOre - player.playerGold - player.playerPlatinum - player.playerDiamonds);
                                main.UserStatsDisplay(player);
                                ClearInputViewer();
                                Console.SetCursorPosition(24, 37);
                                Console.Write("Please select a numeric option from your Menu Display: ");
                                TravelMenu(player, main);
                            }
                        }
                        else //Didn't find, but got ore
                        {
                            ironOre = foundAmount.Next(3 + (player.playerMiningLaserLevel * 2), 20);
                            if (player.playerEmptyCargoSpace == 0)
                            {
                                Console.SetCursorPosition(24, 6);
                                Console.Write("                                                                            ");
                                Console.SetCursorPosition(24, 6);
                                Console.Write("You don't have any empty cargo space on your ship!");
                                main.UserStatsDisplay(player);
                                ClearInputViewer();
                                Console.SetCursorPosition(24, 37);
                                Console.Write("Please select a numeric option from your Menu Display: ");
                                TravelMenu(player, main);
                            }
                            if (ironOre > player.playerEmptyCargoSpace)
                            {
                                Console.SetCursorPosition(24, 6);
                                Console.Write("                                                                            ");
                                Console.SetCursorPosition(24, 6);
                                Console.Write($"You found {ironOre} iron-ore units, but you only have space for");
                                Console.SetCursorPosition(24, 7);
                                Console.Write("                                                                            ");
                                Console.SetCursorPosition(24, 7);
                                Console.Write($"{ player.playerEmptyCargoSpace} units in your ship.");
                                ironOre = player.playerEmptyCargoSpace;
                                player.playerIronOre += ironOre;
                                player.playerEmptyCargoSpace = (player.playerShipCargoSpace - player.playerCopper - player.playerIronOre - player.playerGold - player.playerPlatinum - player.playerDiamonds);
                                main.UserStatsDisplay(player);
                                ClearInputViewer();
                                Console.SetCursorPosition(24, 37);
                                Console.Write("Please select a numeric option from your Menu Display: ");
                                TravelMenu(player, main);
                            }
                            if (ironOre < player.playerEmptyCargoSpace)
                            {
                                Console.SetCursorPosition(24, 6);
                                Console.Write("                                                                            ");
                                Console.SetCursorPosition(24, 6);
                                Console.Write($"You didn't find what you were looking for, but you did find {ironOre}");
                                Console.SetCursorPosition(24, 7);
                                Console.Write("                                                                            ");
                                Console.SetCursorPosition(24, 7);
                                Console.Write($"units of iron-ore...");
                                player.playerIronOre += ironOre;
                                player.playerEmptyCargoSpace = (player.playerShipCargoSpace - player.playerCopper - player.playerIronOre - player.playerGold - player.playerPlatinum - player.playerDiamonds);
                                main.UserStatsDisplay(player);
                                ClearInputViewer();
                                Console.SetCursorPosition(24, 37);
                                Console.Write("Please select a numeric option from your Menu Display: ");
                                TravelMenu(player, main);
                            }
                        }
                    }
                    else
                    {
                        Console.SetCursorPosition(24, 6);
                        Console.Write("                                                                            ");
                        Console.SetCursorPosition(24, 6);
                        Console.Write("Sorry, you don't have the required credits to scan for this!");
                        main.UserStatsDisplay(player);
                        TravelMenu(player, main);
                        ClearInputViewer();
                        Console.SetCursorPosition(24, 37);
                        Console.Write("Please select a numeric option from your Menu Display: ");
                    }
                    break;
                case 4: //Chance to find Diamonds 
                    if (player.playerCredits >= 500) //Check to see if user has credits to scan
                    {
                        player.playerCredits -= 500;
                        chance = findChance.Next(0, 100); //Random for scan success
                        if (chance > (90 - player.playerScannerLevel)) //each scanner level = 10
                        {
                            diamonds = foundAmount.Next(1 + (player.playerMiningLaserLevel * 2), 21); //eac mining laser level = 1
                            if (player.playerEmptyCargoSpace == 0)
                            {
                                Console.SetCursorPosition(24, 6);
                                Console.Write("                                                                            ");
                                Console.SetCursorPosition(24, 6);
                                Console.Write("You don't have any empty cargo space on your ship!");
                                main.UserStatsDisplay(player);
                                ClearInputViewer();
                                Console.SetCursorPosition(24, 37);
                                Console.Write("Please select a numeric option from your Menu Display: ");
                                TravelMenu(player, main);
                            }
                            if (diamonds > player.playerEmptyCargoSpace)  //Check to see if found amount is more than empty cargo space
                            {
                                Console.SetCursorPosition(24, 6);
                                Console.Write("                                                                            ");
                                Console.SetCursorPosition(24, 6);
                                Console.Write($"You found {diamonds} diamond units, but you only have space for");
                                Console.SetCursorPosition(24, 7);
                                Console.Write("                                                                            ");
                                Console.SetCursorPosition(24, 7);
                                Console.Write($"{ player.playerEmptyCargoSpace} units in your ship.");
                                diamonds = player.playerEmptyCargoSpace;
                                player.playerDiamonds += diamonds;
                                player.playerEmptyCargoSpace = (player.playerShipCargoSpace - player.playerCopper - player.playerIronOre - player.playerGold - player.playerPlatinum - player.playerDiamonds);
                                ClearInputViewer();
                                Console.SetCursorPosition(24, 37);
                                Console.Write("Please select a numeric option from your Menu Display: ");
                                main.UserStatsDisplay(player);
                            }

                            else
                            {
                                Console.SetCursorPosition(24, 6);
                                Console.Write("                                                                            ");
                                Console.SetCursorPosition(24, 6);
                                Console.Write($"You were able to mine {diamonds} units of diamonds successfully!");
                                player.playerDiamonds += diamonds;
                                player.playerEmptyCargoSpace = (player.playerShipCargoSpace - player.playerCopper - player.playerIronOre - player.playerGold - player.playerPlatinum - player.playerDiamonds);
                                main.UserStatsDisplay(player);
                                ClearInputViewer();
                                Console.SetCursorPosition(24, 37);
                                Console.Write("Please select a numeric option from your Menu Display: ");
                                TravelMenu(player, main);
                            }
                        }
                        else //Didn't find, but got ore
                        {
                            ironOre = foundAmount.Next(3 + (player.playerMiningLaserLevel * 2), 20);
                            if (player.playerEmptyCargoSpace == 0)
                            {
                                Console.SetCursorPosition(24, 6);
                                Console.Write("                                                                            ");
                                Console.SetCursorPosition(24, 6);
                                Console.Write("You don't have any empty cargo space on your ship!");
                                main.UserStatsDisplay(player);
                                ClearInputViewer();
                                Console.SetCursorPosition(24, 37);
                                Console.Write("Please select a numeric option from your Menu Display: ");
                                TravelMenu(player, main);
                            }
                            if (ironOre > player.playerEmptyCargoSpace)
                            {
                                Console.SetCursorPosition(24, 6);
                                Console.Write("                                                                            ");
                                Console.SetCursorPosition(24, 6);
                                Console.Write($"You found {ironOre} iron-ore units, but you only have space for");
                                Console.SetCursorPosition(24, 7);
                                Console.Write("                                                                            ");
                                Console.SetCursorPosition(24, 7);
                                Console.Write($"{ player.playerEmptyCargoSpace} units in your ship.");
                                ironOre = player.playerEmptyCargoSpace;
                                player.playerIronOre += ironOre;
                                player.playerEmptyCargoSpace = (player.playerShipCargoSpace - player.playerCopper - player.playerIronOre - player.playerGold - player.playerPlatinum - player.playerDiamonds);
                                main.UserStatsDisplay(player);
                                ClearInputViewer();
                                Console.SetCursorPosition(24, 37);
                                Console.Write("Please select a numeric option from your Menu Display: ");
                                TravelMenu(player, main);
                            }
                            if (ironOre < player.playerEmptyCargoSpace)
                            {
                                Console.SetCursorPosition(24, 6);
                                Console.Write("                                                                            ");
                                Console.SetCursorPosition(24, 6);
                                Console.Write($"You didn't find what you were looking for, but you did find {ironOre}");
                                Console.SetCursorPosition(24, 7);
                                Console.Write("                                                                            ");
                                Console.SetCursorPosition(24, 7);
                                Console.Write($"units of iron-ore...");
                                player.playerIronOre += ironOre;
                                player.playerEmptyCargoSpace = (player.playerShipCargoSpace - player.playerCopper - player.playerIronOre - player.playerGold - player.playerPlatinum - player.playerDiamonds);
                                main.UserStatsDisplay(player);
                                ClearInputViewer();
                                Console.SetCursorPosition(24, 37);
                                Console.Write("Please select a numeric option from your Menu Display: ");
                                TravelMenu(player, main);
                            }
                        }
                    }
                    else
                    {
                        Console.SetCursorPosition(24, 6);
                        Console.Write("                                                                            ");
                        Console.SetCursorPosition(24, 6);
                        Console.Write("Sorry, you don't have the required credits to scan for this!");
                        main.UserStatsDisplay(player);
                        ClearInputViewer();
                        TravelMenu(player, main);
                        Console.SetCursorPosition(24, 37);
                        Console.Write("Please select a numeric option from your Menu Display: ");
                    }
                    break;
                case 5:
                    TravelMenu(player, main);
                    break;
            }
        }


        //Combat related methods and displays
        public void LenoreEncounter(Player player, Menus main)
        {
            Lenore lenore = new Lenore();
            FightSequence(player, main, lenore);
        }

        public void EnemyEncounterMenu(Player player, Menus main)
        {
            Random encounterChance = new Random();
            int enc = encounterChance.Next(0, 100);
            if (enc > 0 && enc < 2)
            {
                ClearMainViewer();
                Console.SetCursorPosition(24, 6);
                Console.Write("                                                                            ");
                Console.SetCursorPosition(24, 6);
                Console.Write($"How unlucky for you, you found Lenore the Programming Master!!!!!!!");
                LenoreEncounter(player, main);
            }
            if (enc > 1 && enc < 16)
            {
                Enemies enemies = new Enemies();
                enemies.hp = enemies.HPGenerator();
                enemies.credits = enemies.CreditsGenerator();
                enemies.attackPower = enemies.AttackGenerator();
                Random findChance = new Random();
                int chance = Convert.ToInt32(findChance.Next(0, 100));


                if (chance >= 0 && chance <= 25)
                {
                    enemies.name = new Sith().name;
                }
                else if (chance > 25 && chance <= 50)
                {
                    enemies.name = new Romulan().name;
                }
                else if (chance > 50 && chance <= 75)
                {
                    enemies.name = new GrayAlien().name;
                }
                else if (chance > 75 && chance <= 100)
                {
                    enemies.name = new Pirates().name;
                }
                ClearMainViewer();
                Console.SetCursorPosition(24, 6);
                Console.Write($"During your travels, you have encountered a {enemies.name} ");
                Console.SetCursorPosition(24, 7);
                Console.Write($"with {enemies.hp} ship durability!!");
                ClearMenuScreen();
                Console.SetCursorPosition(127, 5);
                Console.Write("1. Fight the enemy!        ");
                Console.SetCursorPosition(127, 6);
                Console.Write("                           ");
                Console.SetCursorPosition(127, 7);
                Console.Write("2. Negotiate a surrender...");
                Console.SetCursorPosition(127, 8);
                Console.Write("You will lose credits      ");
                Console.SetCursorPosition(127, 9);
                Console.Write("                           ");
                Console.SetCursorPosition(127, 10);
                Console.Write("                           ");
                ClearInputViewer();
                Console.SetCursorPosition(24, 37);
                Console.Write("Please select a numeric option from your Menu Display: ");
                string selectCombat = Console.ReadLine();
                int selection = player.InputValidation(selectCombat, 1, 2);
                switch (selection)
                {
                    case 1:
                        FightSequence(player, main, enemies);
                        break;
                    case 2:
                        {
                            Console.SetCursorPosition(24, 8);
                            Console.Write($"You have surrendered {player.playerCredits / 2} credits to the enemy!!! Weak.");
                            player.playerCredits -= (player.playerCredits / 2);
                            ClearInputViewer();
                            Console.SetCursorPosition(24, 37);
                            Console.Write("Press <ENTER> to finish travelling to your destination...");
                            UserStatsDisplay(player);
                            Console.ReadLine();
                            break;
                        }
                }
            }
        }

        public void FightSequence(Player player, Menus main, Enemies enemies)
        {
            Random dmgMod = new Random();
            int addedVal;
            while (player.shipDurability > 0 && enemies.hp > 0)
            {
                Console.SetCursorPosition(24, 8);
                Console.Write("                                                                            ");
                Console.SetCursorPosition(24, 8);
                addedVal = dmgMod.Next(-2, 5);
                Console.Write($"You hit the enemy for {(player.playerWeaponLevel * 11) + addedVal} damage!");
                System.Threading.Thread.Sleep(500);
                Console.SetCursorPosition(24, 9);
                Console.Write("                                                                            ");
                Console.SetCursorPosition(24, 9);
                enemies.hp -= (player.playerWeaponLevel * 10) + addedVal;
                addedVal = dmgMod.Next(-3, 3);
                Console.Write($"The {enemies.name} hit your ship for {enemies.attackPower + addedVal} damange!");
                player.shipDurability -= enemies.attackPower + addedVal;
                UserStatsDisplay(player);
                System.Threading.Thread.Sleep(500);
            }
            if (player.shipDurability <= 0)
            {
                Console.SetCursorPosition(24, 13);
                Console.Write($"Your ship has been destroyed by {enemies.name}!!");
                Console.SetCursorPosition(24, 14);
                Console.Write($"You need to try harder next time...");
                Console.ReadLine();
                Environment.Exit(0);  
            }
            if (enemies.hp <= 0)
            {
                Console.SetCursorPosition(24, 13);
                Console.Write($"You have defeated the {enemies.name} and ");
                Console.SetCursorPosition(24, 14);
                Console.Write($"received {enemies.credits} credits from the fight!");
                player.playerCredits += enemies.credits;
                ClearInputViewer();
                Console.SetCursorPosition(24, 37);
                Console.Write("Press <ENTER> to continue...");
                UserStatsDisplay(player);
            }
        }

        //Clear the various screens of content
        public void ClearMenuScreen()
        {
            Console.SetCursorPosition(127, 5);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 6);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 7);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 8);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 9);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 10);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 11);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 12);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 13);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 14);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 15);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 16);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 17);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 18);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 19);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 20);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 21);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 22);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 23);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 24);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 25);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 26);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 27);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 28);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 29);
            Console.Write("                           ");
            Console.SetCursorPosition(24, 37);
        }

        public void ClearInputViewer()
        {
            Console.SetCursorPosition(24, 37);
            Console.Write("                                                                              ");
            Console.SetCursorPosition(24, 38);
            Console.Write("                                                                              ");
            Console.SetCursorPosition(24, 39);
            Console.Write("                                                                              ");
            Console.SetCursorPosition(24, 40);
            Console.Write("                                                                              ");
            Console.SetCursorPosition(24, 41);
            Console.Write("                                                                              ");
            Console.SetCursorPosition(24, 42);
            Console.Write("                                                                              ");
            Console.SetCursorPosition(24, 43);
            Console.Write("                                                                              ");
            Console.SetCursorPosition(24, 44);
            Console.Write("                                                                              ");
            Console.SetCursorPosition(24, 45);
            Console.Write("                                                                              ");
            Console.SetCursorPosition(24, 46);
            Console.Write("                                                                              ");
        }

        public void ClearMainViewer()
        {
            Console.SetCursorPosition(24, 5);
            Console.Write("                                                                            ");
            Console.SetCursorPosition(24, 6);
            Console.Write("                                                                            ");
            Console.SetCursorPosition(24, 7);
            Console.Write("                                                                            ");
            Console.SetCursorPosition(24, 8);
            Console.Write("                                                                            ");
            Console.SetCursorPosition(24, 9);
            Console.Write("                                                                            ");
            Console.SetCursorPosition(24, 10);
            Console.Write("                                                                            ");
            Console.SetCursorPosition(24, 11);
            Console.Write("                                                                            ");
            Console.SetCursorPosition(24, 12);
            Console.Write("                                                                            ");
            Console.SetCursorPosition(24, 13);
            Console.Write("                                                                            ");
            Console.SetCursorPosition(24, 14);
            Console.Write("                                                                            ");
            Console.SetCursorPosition(24, 15);
            Console.Write("                                                                            ");
            Console.SetCursorPosition(24, 16);
            Console.Write("                                                                            ");
            Console.SetCursorPosition(24, 17);
            Console.Write("                                                                            ");
            Console.SetCursorPosition(24, 18);
            Console.Write("                                                                            ");
            Console.SetCursorPosition(24, 19);
            Console.Write("                                                                            ");
            Console.SetCursorPosition(24, 20);
            Console.Write("                                                                            ");
            Console.SetCursorPosition(24, 21);
            Console.Write("                                                                            ");
            Console.SetCursorPosition(24, 22);
            Console.Write("                                                                            ");
            Console.SetCursorPosition(24, 23);
            Console.Write("                                                                            ");
            Console.SetCursorPosition(24, 24);
            Console.Write("                                                                            ");
            Console.SetCursorPosition(24, 25);
            Console.Write("                                                                            ");
            Console.SetCursorPosition(24, 26);
            Console.Write("                                                                            ");
            Console.SetCursorPosition(24, 27);
            Console.Write("                                                                            ");
            Console.SetCursorPosition(24, 28);
            Console.Write("                                                                            ");
            Console.SetCursorPosition(24, 37);
        }

        //Screen Displays for various menus and character statistics
        public int CharacterSelectionDisplay(Player player)
        {
            ClearMainViewer();
            ClearInputViewer();
            ClearMenuScreen();
            Console.SetCursorPosition(24, 5);
            Console.Write("What type of character would you like to be?                                ");
            Console.SetCursorPosition(24, 6);
            Console.Write("1. Trader:        Starting Credits - 5,000                                  ");
            Console.SetCursorPosition(24, 7);
            Console.Write("                  Starting Cargo Space = 20                                 ");
            Console.SetCursorPosition(24, 8);
            Console.Write("                  Starting Weapon Level = 1                                 ");
            Console.SetCursorPosition(24, 9);
            Console.Write("                                                                            ");
            Console.SetCursorPosition(24, 10);
            Console.Write("2. Entrepreneuer: Starting Credits 10,000                                   ");
            Console.SetCursorPosition(24, 11);
            Console.Write("                  Starting Cargo Space = 5                                  ");
            Console.SetCursorPosition(24, 12);
            Console.Write("                  Starting Weapon Level = 1                                 ");
            Console.SetCursorPosition(24, 13);
            Console.Write("                                                                            ");
            Console.SetCursorPosition(24, 14);
            Console.Write("3.Bounty Hunter:  Starting Credits 7,500                                    ");
            Console.SetCursorPosition(24, 15);
            Console.Write("                  Starting Cargo Space = 15                                 ");
            Console.SetCursorPosition(24, 16);
            Console.Write("                  Starting Weapon Level = 2                                 ");
            Console.SetCursorPosition(24, 17);
            Console.Write("                                                                            ");
            Console.SetCursorPosition(24, 18);
            Console.Write("4. Miner:         Starting Credits - 1,000                                  ");
            Console.SetCursorPosition(24, 19);
            Console.Write("                  Starting Cargo Space = 30                                 ");
            Console.SetCursorPosition(24, 20);
            Console.Write("                  Starting Weapon Level = 1                                 ");
            Console.SetCursorPosition(24, 21);
            Console.Write("                  Starting Scanner Level = 1                                ");
            Console.SetCursorPosition(24, 22);
            Console.Write("                                                                            ");
            Console.SetCursorPosition(24, 23);
            Console.Write("                                                                            ");
            Console.SetCursorPosition(24, 24);
            Console.Write("                                                                            ");
            Console.SetCursorPosition(24, 25);
            Console.Write("                                                                            ");
            Console.SetCursorPosition(24, 26);
            Console.Write("                                                                            ");
            Console.SetCursorPosition(24, 27);
            Console.Write("                                                                            ");
            Console.SetCursorPosition(24, 28);
            Console.Write("                                                                            ");
            Console.SetCursorPosition(24, 37);
            Console.Write("Please select a numeric option from the Main Console: ");
            string input = Console.ReadLine();
            int selection = player.InputValidation(input, 1, 4);
            return selection;
        }

        public void MainMenuDisplay(Player player, Menus main)
        {
            ClearMenuScreen();
            Console.SetCursorPosition(127, 5);
            Console.Write("1. Travel                  ");
            Console.SetCursorPosition(127, 6);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 7);
            Console.Write("2. Exit Game               ");
            Console.SetCursorPosition(127, 8);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 9);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 10);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 11);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 12);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 13);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 14);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 15);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 16);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 17);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 18);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 19);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 20);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 21);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 22);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 23);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 24);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 25);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 26);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 27);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 27);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 29);
            Console.Write("                           ");
            Console.SetCursorPosition(24, 37);
            Console.Write("Please select a numeric option from your Menu Display: ");
            string userSelection = Console.ReadLine();
            int mainOut = player.InputValidation(userSelection, 1, 2);
            if (mainOut == 1)
            {
                TravelMenu(player, main);
            }
            if (mainOut == 2)
            {
                Environment.Exit(0);
            }
        }

        public int ShipUgradeDisplay(Player player, Menus main)
        {
            //4. Upgrade ship weapons\n5. Repair Ship Damage\n6. Return to Planet Menu");
            ClearMenuScreen();
            ClearInputViewer();
            Console.SetCursorPosition(24, 5);
            Console.Write($"Upgrade Cargo Capacity by 5 for 1000 credits.                              ");
            Console.SetCursorPosition(24, 6);
            Console.Write("                                                                            ");
            Console.SetCursorPosition(24, 7);
            Console.Write($"It will cost: your ship scanner level multiplied by 1100 credits each ");
            Console.SetCursorPosition(24, 8);
            Console.Write("time you upgrade.                      ");
            Console.SetCursorPosition(24, 9);
            Console.Write("                                                                            ");
            Console.SetCursorPosition(24, 10);
            Console.Write($"It will cost: your mining laser level multiplied by 1500 credits to upgrade");
            Console.SetCursorPosition(24, 11);
            Console.Write(" your Mining Laser.                    ");
            Console.SetCursorPosition(24, 12);
            Console.Write("                                                                            ");
            Console.SetCursorPosition(24, 13);
            Console.Write($"It will cost: your mining laser level multiplied by 1500 credits to upgrade");
            Console.SetCursorPosition(24, 14);
            Console.Write("your Mining Laser.                     ");
            Console.SetCursorPosition(24, 15);
            Console.Write("                                                                            ");
            Console.SetCursorPosition(24, 16);
            Console.Write($"It will cost: your weapons level multiplied by 2000 credits to upgrade     ");
            Console.SetCursorPosition(24, 17);
            Console.Write("your ship weapons.                   ");
            Console.SetCursorPosition(24, 18);
            Console.Write("                                                                            ");
            Console.SetCursorPosition(24, 19);
            Console.Write($"It will cost: 1000 credits to add 20 durability to your ship.              ");
            Console.SetCursorPosition(127, 5);
            Console.Write("1. Upgrade Cargo Capacity  ");
            Console.SetCursorPosition(127, 6);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 7);
            Console.Write("2. Upgrade Ship Scanner -  ");
            Console.SetCursorPosition(127, 8);
            Console.Write("Increase mineral find rate ");
            Console.SetCursorPosition(127, 9);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 10);
            Console.Write("3. Upgrade mining laser -  ");
            Console.SetCursorPosition(127, 11);
            Console.Write("Increase return rate       ");
            Console.SetCursorPosition(127, 12);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 13);
            Console.Write("4. Upgrade Ship Weapons    ");
            Console.SetCursorPosition(127, 14);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 15);
            Console.Write("5. Upgrade Ship Armor      ");
            Console.SetCursorPosition(127, 16);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 17);
            Console.Write("6. Repair Ship Damage      ");
            Console.SetCursorPosition(127, 18);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 19);
            Console.Write("7. Return to Planet Menu   ");
            Console.SetCursorPosition(24, 37);
            Console.Write("Please select a numeric option from your Menu Display: ");
            string userSelection = Console.ReadLine();
            ClearMainViewer();
            int mainOut = player.InputValidation(userSelection, 1, 7);
            return mainOut;
        }

        public int TravelMenuDisplay(Player player, Menus main)
        {
            ClearMenuScreen();
            Console.SetCursorPosition(127, 5);
            Console.Write("1. Travel to Venus         ");
            Console.SetCursorPosition(127, 6);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 7);
            Console.Write("2. Travel to Mars          ");
            Console.SetCursorPosition(127, 8);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 9);
            Console.Write("3. Travel to Earth         ");
            Console.SetCursorPosition(127, 10);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 11);
            Console.Write("4. Travel to Mercury       ");
            Console.SetCursorPosition(127, 12);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 13);
            Console.Write("5. Travel to Pluto         ");
            Console.SetCursorPosition(127, 14);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 15);
            Console.Write("6. Mine an Asteroid        ");
            Console.SetCursorPosition(127, 16);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 17);
            Console.Write("7. Be a Space Pirate       ");
            Console.SetCursorPosition(127, 18);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 19);
            Console.Write("8. Challenge the Final Boss");
            Console.SetCursorPosition(127, 20);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 21);
            Console.Write("9. Return to Main Menu     ");
            Console.SetCursorPosition(127, 22);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 23);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 24);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 25);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 26);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 27);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 27);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 29);
            Console.Write("                           ");
            Console.SetCursorPosition(24, 37);
            Console.Write("Please select a numeric option from your Menu Display: ");
            string userSelection = Console.ReadLine();
            int selection = player.InputValidation(userSelection, 1, 9);
            return selection;
        }

        public int PlanetMenuDisplay(Player player,Planets planet, Menus main)
        {
            ClearMenuScreen();
            ClearMainViewer();
            ClearInputViewer();
            Console.SetCursorPosition(127, 5);
            Console.Write("1. Sell Minerals           ");
            Console.SetCursorPosition(127, 6);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 7);
            Console.Write("2. Upgrade Ship Components ");
            Console.SetCursorPosition(127, 8);
            Console.Write("or repair ship             ");
            Console.SetCursorPosition(127, 9);
            Console.Write("3. Leave Planet            ");
            Console.SetCursorPosition(24, 5);
            Console.Write($"This planet buys copper for {planet.copperValue} credits per unit.     ");
            Console.SetCursorPosition(24, 6);
            Console.Write("                                                                            ");
            Console.SetCursorPosition(24, 7);
            Console.Write($"This planet buys gold  {planet.goldValue} credits per unit.            ");
            Console.SetCursorPosition(24, 8);
            Console.Write("                                                                            ");
            Console.SetCursorPosition(24, 9);
            Console.Write($"This planet buys platinum for {planet.platinumValue} credits per unit.");
            Console.SetCursorPosition(24, 10);
            Console.Write("                                                                            ");
            Console.SetCursorPosition(24, 11);
            Console.Write($"This planet buys diamond for {planet.diamondValue} credits per unit. ");
            Console.SetCursorPosition(24, 12);
            Console.Write("                                                                            ");
            Console.SetCursorPosition(24, 13);
            Console.Write($"This planet buys iron-ore for {planet.ironValue} credits per unit.     ");
            Console.SetCursorPosition(24, 14);
            Console.Write("                                                                            ");
            Console.SetCursorPosition(24, 37);
            Console.Write("Please select a numeric option from your Menu Display: ");
            string userSelection = Console.ReadLine();
            int selection = player.InputValidation(userSelection, 1, 3);
            return selection;
        }

        public int SellGoodsMenuDisplay(Player player, Planets planet, Menus main)
        {
            ClearInputViewer();
            ClearMenuScreen();
            UserStatsDisplay(player);
            Console.SetCursorPosition(127, 5);
            Console.Write("1. Sell Copper             ");
            Console.SetCursorPosition(127, 6);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 7);
            Console.Write("2. Sell Gold               ");
            Console.SetCursorPosition(127, 8);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 9);
            Console.Write("3. Sell Platinum           ");
            Console.SetCursorPosition(127, 10);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 11);
            Console.Write("4. Sell Diamonds           ");
            Console.SetCursorPosition(127, 12);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 13);
            Console.Write("5. Sell Iron-Ore           ");
            Console.SetCursorPosition(127, 14);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 15);
            Console.Write("6. Return to Planet Menu   ");
            Console.SetCursorPosition(24, 37);
            Console.Write("Please select a numeric option from your Menu Display: ");
            string userSelection = Console.ReadLine();
            int selection = player.InputValidation(userSelection, 1, 6);
            ClearInputViewer();
            return selection;
        }

        public int AsteroidMiningDisplay(Player player, Menus main)
        {
            ClearInputViewer();
            ClearMainViewer();
            ClearMenuScreen();
            Console.SetCursorPosition(127, 5);
            Console.Write("1. Mine for Copper         ");
            Console.SetCursorPosition(127, 6);
            Console.Write("       Cost: 200 Credits   ");
            Console.SetCursorPosition(127, 7);
            Console.Write("2. Mine for Gold           ");
            Console.SetCursorPosition(127, 8);
            Console.Write("       Cost: 300 Credits   ");
            Console.SetCursorPosition(127, 9);
            Console.Write("3. Mine for Platinum       ");
            Console.SetCursorPosition(127, 10);
            Console.Write("       Cost: 400 Credits   ");
            Console.SetCursorPosition(127, 11);
            Console.Write("4. Mine for Diamonds       ");
            Console.SetCursorPosition(127, 12);
            Console.Write("       Cost: 500 Credits   ");
            Console.SetCursorPosition(127, 13);
            Console.Write("5. Return to Travel Menu   ");
            Console.SetCursorPosition(127, 14);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 15);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 16);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 17);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 18);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 19);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 20);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 21);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 22);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 23);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 24);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 25);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 26);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 27);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 28);
            Console.Write("                           ");
            Console.SetCursorPosition(127, 29);
            Console.Write("                           ");
            Console.SetCursorPosition(24, 37);
            Console.Write("Please select a numeric option from your Menu Display: ");
            string userSelection = Console.ReadLine();
            int selection = player.InputValidation(userSelection, 1, 5);
            return selection;
        }

        public void UserStatsDisplay(Player player)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            //Display User Class
            Console.SetCursorPosition(124, 33);
            Console.Write("                              ");
            Console.SetCursorPosition(124, 33);
            Console.Write($"User Class: {player.playerType}");
            //Display User Credits
            Console.SetCursorPosition(124, 34);
            Console.Write("                              ");
            Console.SetCursorPosition(124, 34);
            Console.Write($"User Credits: {player.playerCredits}");
            //Display Cargo
            Console.SetCursorPosition(124, 35);
            Console.Write("                              ");
            Console.SetCursorPosition(124, 35);
            Console.Write("            CARGO             ");
            //Display Iron Ore and Copper
            Console.SetCursorPosition(124, 36);
            Console.Write("                              ");
            Console.SetCursorPosition(124, 36);
            Console.Write($"IronOre: {player.playerIronOre}   Copper: {player.playerCopper}      ");
            //Display Gold and Platinum
            Console.SetCursorPosition(124, 37);
            Console.Write("                              ");
            Console.SetCursorPosition(124, 37);
            Console.Write($"Gold: {player.playerGold}      Platinum: {player.playerPlatinum}    ");
            //Display Diamonds and Empty Space
            Console.SetCursorPosition(124, 38);
            Console.Write("                              ");
            Console.SetCursorPosition(124, 38);
            Console.Write($"Diamonds: {player.playerDiamonds}  Empty Space: {player.playerEmptyCargoSpace} ");
            Console.SetCursorPosition(124, 39);
            Console.Write("                              ");
            Console.SetCursorPosition(124, 40);
            Console.Write("                              ");
            Console.SetCursorPosition(124, 40);
            //Display ship systems and upgrades
            Console.Write("        SHIP SYSTEMS          ");
            //Display Ship Scanner
            Console.SetCursorPosition(124, 41);
            Console.Write("                              ");
            Console.SetCursorPosition(124, 41);
            Console.Write($"Ship Scanner Level: {player.playerScannerLevel}        ");
            //Display Ship Mining Laser
            Console.SetCursorPosition(124, 42);
            Console.Write("                              ");
            Console.SetCursorPosition(124, 42);
            Console.Write($"Ship Mining Laser Level: {player.playerMiningLaserLevel}    ");
            //Display Ship Weapons
            Console.SetCursorPosition(124, 43);
            Console.Write("                              ");
            Console.SetCursorPosition(124, 43);
            Console.Write($"Ship Weapons Level: {player.playerWeaponLevel}        ");
            //Display Ship Durability
            Console.SetCursorPosition(124, 44);
            Console.Write("                              ");
            Console.SetCursorPosition(124, 44);
            Console.Write($"Ship Durability: {player.shipDurability} / {player.shipMaxDurability}");
            Console.SetCursorPosition(124, 45);
            Console.Write("                              ");
            Console.SetCursorPosition(124, 46);
            Console.Write("                              ");
            Console.ForegroundColor = ConsoleColor.Blue;
        }

        //Planet graphics
        public void DisplayMars()
        {
            Console.ForegroundColor = ConsoleColor.Red;
            ClearMainViewer();
            Console.SetCursorPosition(23, 28);
            Console.Write("                              +`:i)))IIIII)ii+'   ");
            System.Threading.Thread.Sleep(300);
            Console.SetCursorPosition(23, 26);
            Console.Write("                              +`:i)))IIIII)ii+   ");
            Console.SetCursorPosition(23, 27);
            Console.Write("                            )i)iIIIITIIITIIII))i+:' ");
            Console.SetCursorPosition(23, 28);
            Console.Write("                          +:=i)))iIITTTTTTTTIIIII)=+   ");
            System.Threading.Thread.Sleep(300);
            Console.SetCursorPosition(23, 24);
            Console.Write("                              +`:i)))IIIII)ii+   ");
            Console.SetCursorPosition(23, 25);
            Console.Write("                            )i)iIIIITIIITIIII))i+:'   ");
            Console.SetCursorPosition(23, 26);
            Console.Write("                          +:=i)))iIITTTTTTTTIIIII)=+    ");
            Console.SetCursorPosition(23, 27);
            Console.Write("                        'ii++::i))I)ITTTTTTTTTTIIII)=+'   ");
            Console.SetCursorPosition(23, 28);
            Console.Write("                       ,+)IIITI+:+i)I))TTTTLLTTTTTII))=,   ");
            System.Threading.Thread.Sleep(300);
            Console.SetCursorPosition(23, 22);
            Console.Write("                              +`:i)))IIIII)ii+   ");
            Console.SetCursorPosition(23, 23);
            Console.Write("                            )i)iIIIITIIITIIII))i+:'   ");
            Console.SetCursorPosition(23, 24);
            Console.Write("                          +:=i)))iIITTTTTTTTIIIII)=+   ");
            Console.SetCursorPosition(23, 25);
            Console.Write("                        'ii++::i))I)ITTTTTTTTTTIIII)=+'   ");
            Console.SetCursorPosition(23, 26);
            Console.Write("                       ,+)IIITI+:+i)I))TTTTLLTTTTTII))=,  ");
            Console.SetCursorPosition(23, 27);
            Console.Write("                      ;=)ITTTTLTTI=:i))I)TTTLLLTTTTTII)i;  ");
            Console.SetCursorPosition(23, 28);
            Console.Write("                     ;:)IITTLLTLLLLT=;+i)I)ITTTTLTTTII))i;  ");
            System.Threading.Thread.Sleep(300);
            Console.SetCursorPosition(23, 20);
            Console.Write("                              +`:i)))IIIII)ii+   ");
            Console.SetCursorPosition(23, 21);
            Console.Write("                            )i)iIIIITIIITIIII))i+:'   ");
            Console.SetCursorPosition(23, 22);
            Console.Write("                          +:=i)))iIITTTTTTTTIIIII)=+  ");
            Console.SetCursorPosition(23, 23);
            Console.Write("                        'ii++::i))I)ITTTTTTTTTTIIII)=+'  ");
            Console.SetCursorPosition(23, 24);
            Console.Write("                       ,+)IIITI+:+i)I))TTTTLLTTTTTII))=,  ");
            Console.SetCursorPosition(23, 25);
            Console.Write("                      ;=)ITTTTLTTI=:i))I)TTTLLLTTTTTII)i;  ");
            Console.SetCursorPosition(23, 26);
            Console.Write("                     ;:)IITTLLTLLLLT=;+i)I)ITTTTLTTTII))i;  ");
            Console.SetCursorPosition(23, 27);
            Console.Write("                    ;ii)))IITTLLLLLLLLT=:i)II)TTTTLTTIII)i;  ");
            Console.SetCursorPosition(23, 28);
            Console.Write("                   'i=i)IIIIIITTLLLLLLHLL=:i)II)TTTTTTIII)i'  ");
            System.Threading.Thread.Sleep(300);
            Console.SetCursorPosition(23, 18);
            Console.Write("                              +`:i)))IIIII)ii+   ");
            Console.SetCursorPosition(23, 19);
            Console.Write("                            )i)iIIIITIIITIIII))i+:'   ");
            Console.SetCursorPosition(23, 20);
            Console.Write("                          +:=i)))iIITTTTTTTTIIIII)=+  ");
            Console.SetCursorPosition(23, 21);
            Console.Write("                        'ii++::i))I)ITTTTTTTTTTIIII)=+'  ");
            Console.SetCursorPosition(23, 22);
            Console.Write("                       ,+)IIITI+:+i)I))TTTTLLTTTTTII))=,  ");
            Console.SetCursorPosition(23, 23);
            Console.Write("                      ;=)ITTTTLTTI=:i))I)TTTLLLTTTTTII)i; ");
            Console.SetCursorPosition(23, 24);
            Console.Write("                     ;:)IITTLLTLLLLT=;+i)I)ITTTTLTTTII))i;  ");
            Console.SetCursorPosition(23, 25);
            Console.Write("                    ;ii)))IITTLLLLLLLLT=:i)II)TTTTLTTIII)i;  ");
            Console.SetCursorPosition(23, 26);
            Console.Write("                   'i=i)IIIIIITTLLLLLLHLL=:i)II)TTTTTTIII)i'  ");
            Console.SetCursorPosition(23, 27);
            Console.Write("                   +i.i)IIITTTTITTLLLHHLLLL);=)II)ITTTTII)i+    ");
            Console.SetCursorPosition(23, 28);
            Console.Write("                   'i=i)IIIIIITTLLLLLLHLL=:i)II)TTTTTTIII)i'  ");
            System.Threading.Thread.Sleep(300);
            Console.SetCursorPosition(23, 16);
            Console.Write("                              +`:i)))IIIII)ii+   ");
            Console.SetCursorPosition(23, 17);
            Console.Write("                            )i)iIIIITIIITIIII))i+:'  ");
            Console.SetCursorPosition(23, 18);
            Console.Write("                          +:=i)))iIITTTTTTTTIIIII)=+  ");
            Console.SetCursorPosition(23, 19);
            Console.Write("                        'ii++::i))I)ITTTTTTTTTTIIII)=+'   ");
            Console.SetCursorPosition(23, 20);
            Console.Write("                       ,+)IIITI+:+i)I))TTTTLLTTTTTII))=,  ");
            Console.SetCursorPosition(23, 21);
            Console.Write("                      ;=)ITTTTLTTI=:i))I)TTTLLLTTTTTII)i;  ");
            Console.SetCursorPosition(23, 22);
            Console.Write("                     ;:)IITTLLTLLLLT=;+i)I)ITTTTLTTTII))i;  ");
            Console.SetCursorPosition(23, 23);
            Console.Write("                    ;ii)))IITTLLLLLLLLT=:i)II)TTTTLTTIII)i;   ");
            Console.SetCursorPosition(23, 24);
            Console.Write("                   'i=i)IIIIIITTLLLLLLHLL=:i)II)TTTTTTIII)i'  ");
            Console.SetCursorPosition(23, 25);
            Console.Write("                   +i.i)IIITTTTITTLLLHHLLLL);=)II)ITTTTII)i+    ");
            Console.SetCursorPosition(23, 26);
            Console.Write("                   'i=i)IIIIIITTLLLLLLHLL=:i)II)TTTTTTIII)i'   ");
            Console.SetCursorPosition(23, 27);
            Console.Write("                    ;ii)))IITTLLLLLLLLT=:i)II)TTTTLTTIII)i;   ");
            Console.SetCursorPosition(23, 28);
            Console.Write("                     ;i)IITTLLTLLLLT=;+i)I)ITTTTLTTTII))i;   ");
            System.Threading.Thread.Sleep(300);
            Console.SetCursorPosition(23, 14);
            Console.Write("                              +`:i)))IIIII)ii+   ");
            Console.SetCursorPosition(23, 15);
            Console.Write("                            )i)iIIIITIIITIIII))i+:'   ");
            Console.SetCursorPosition(23, 16);
            Console.Write("                          +:=i)))iIITTTTTTTTIIIII)=+   ");
            Console.SetCursorPosition(23, 17);
            Console.Write("                        'ii++::i))I)ITTTTTTTTTTIIII)=+'   ");
            Console.SetCursorPosition(23, 18);
            Console.Write("                       ,+)IIITI+:+i)I))TTTTLLTTTTTII))=,   ");
            Console.SetCursorPosition(23, 19);
            Console.Write("                      ;=)ITTTTLTTI=:i))I)TTTLLLTTTTTII)i;   ");
            Console.SetCursorPosition(23, 20);
            Console.Write("                     ;:)IITTLLTLLLLT=;+i)I)ITTTTLTTTII))i;   ");
            Console.SetCursorPosition(23, 21);
            Console.Write("                    ;ii)))IITTLLLLLLLLT=:i)II)TTTTLTTIII)i;   ");
            Console.SetCursorPosition(23, 22);
            Console.Write("                   'i=i)IIIIIITTLLLLLLHLL=:i)II)TTTTTTIII)i'  ");
            Console.SetCursorPosition(23, 23);
            Console.Write("                   +i.i)IIITTTTITTLLLHHLLLL);=)II)ITTTTII)i+    ");
            Console.SetCursorPosition(23, 24);
            Console.Write("                   'i=i)IIIIIITTLLLLLLHLL=:i)II)TTTTTTIII)i'    ");
            Console.SetCursorPosition(23, 25);
            Console.Write("                    ;ii)))IITTLLLLLLLLT=:i)II)TTTTLTTIII)i;    ");
            Console.SetCursorPosition(23, 26);
            Console.Write("                     ;i)IITTLLTLLLLT=;+i)I)ITTTTLTTTII))i;     ");
            Console.SetCursorPosition(23, 27);
            Console.Write("                      ;=)ITTTTLTTI=:i))I)TTTLLLTTTTTII)i;    ");
            Console.SetCursorPosition(23, 28);
            System.Threading.Thread.Sleep(300);
            Console.SetCursorPosition(23, 12);
            Console.Write("                              +`:i)))IIIII)ii+    ");
            Console.SetCursorPosition(23, 13);
            Console.Write("                            )i)iIIIITIIITIIII))i+:'   ");
            Console.SetCursorPosition(23, 14);
            Console.Write("                          +:=i)))iIITTTTTTTTIIIII)=+   ");
            Console.SetCursorPosition(23, 15);
            Console.Write("                        'ii++::i))I)ITTTTTTTTTTIIII)=+'  ");
            Console.SetCursorPosition(23, 16);
            Console.Write("                       ,+)IIITI+:+i)I))TTTTLLTTTTTII))=,  ");
            Console.SetCursorPosition(23, 17);
            Console.Write("                      ;=)ITTTTLTTI=:i))I)TTTLLLTTTTTII)i;  ");
            Console.SetCursorPosition(23, 18);
            Console.Write("                     ;:)IITTLLTLLLLT=;+i)I)ITTTTLTTTII))i;  ");
            Console.SetCursorPosition(23, 19);
            Console.Write("                    ;ii)))IITTLLLLLLLLT=:i)II)TTTTLTTIII)i;  ");
            Console.SetCursorPosition(23, 20);
            Console.Write("                   'i=i)IIIIIITTLLLLLLHLL=:i)II)TTTTTTIII)i'  ");
            Console.SetCursorPosition(23, 21);
            Console.Write("                   +i.i)IIITTTTITTLLLHHLLLL);=)II)ITTTTII)i+   ");
            Console.SetCursorPosition(23, 22);
            Console.Write("                   'i=i)IIIIIITTLLLLLLHLL=:i)II)TTTTTTIII)i'  ");
            Console.SetCursorPosition(23, 23);
            Console.Write("                    ;ii)))IITTLLLLLLLLT=:i)II)TTTTLTTIII)i;    ");
            Console.SetCursorPosition(23, 24);
            Console.Write("                     ;i)IITTLLTLLLLT=;+i)I)ITTTTLTTTII))i;      ");
            Console.SetCursorPosition(23, 25);
            Console.Write("                      ;=)ITTTTLTTI=:i))I)TTTLLLTTTTTII)i;        ");
            Console.SetCursorPosition(23, 26);
            Console.Write("                       i+)IIITI+:+i)I))TTTTLLTTTTTII))=,         ");
            Console.SetCursorPosition(23, 27);
            Console.Write("                        i,i++::i))I)ITTTTTTTTTTIIII)=+'           ");
            Console.SetCursorPosition(23, 28);
            Console.Write("                          ::=i)))iIITTTTTTTTIIIII)=+            ");
            System.Threading.Thread.Sleep(300);
            Console.SetCursorPosition(23, 10);
            Console.Write("                              +`:i)))IIIII)ii+   ");
            Console.SetCursorPosition(23, 11);
            Console.Write("                            )i)iIIIITIIITIIII))i+:'   ");
            Console.SetCursorPosition(23, 12);
            Console.Write("                          +:=i)))iIITTTTTTTTIIIII)=+   ");
            Console.SetCursorPosition(23, 13);
            Console.Write("                        'ii++::i))I)ITTTTTTTTTTIIII)=+'  ");
            Console.SetCursorPosition(23, 14);
            Console.Write("                       ,+)IIITI+:+i)I))TTTTLLTTTTTII))=,   ");
            Console.SetCursorPosition(23, 15);
            Console.Write("                      ;=)ITTTTLTTI=:i))I)TTTLLLTTTTTII)i;   ");
            Console.SetCursorPosition(23, 16);
            Console.Write("                     ;:)IITTLLTLLLLT=;+i)I)ITTTTLTTTII))i;   ");
            Console.SetCursorPosition(23, 17);
            Console.Write("                    ;ii)))IITTLLLLLLLLT=:i)II)TTTTLTTIII)i;   ");
            Console.SetCursorPosition(23, 18);
            Console.Write("                   'i=i)IIIIIITTLLLLLLHLL=:i)II)TTTTTTIII)i'   ");
            Console.SetCursorPosition(23, 19);
            Console.Write("                   +i.i)IIITTTTITTLLLHHLLLL);=)II)ITTTTII)i+    ");
            Console.SetCursorPosition(23, 20);
            Console.Write("                   'i=i)IIIIIITTLLLLLLHLL=:i)II)TTTTTTIII)i'   ");
            Console.SetCursorPosition(23, 21);
            Console.Write("                    ;ii)))IITTLLLLLLLLT=:i)II)TTTTLTTIII)i;    ");
            Console.SetCursorPosition(23, 22);
            Console.Write("                     ;i)IITTLLTLLLLT=;+i)I)ITTTTLTTTII))i;           ");
            Console.SetCursorPosition(23, 23);
            Console.Write("                      ;=)ITTTTLTTI=:i))I)TTTLLLTTTTTII)i;        ");
            Console.SetCursorPosition(23, 24);
            Console.Write("                       i+)IIITI+:+i)I))TTTTLLTTTTTII))=,          ");
            Console.SetCursorPosition(23, 25);
            Console.Write("                        i,i++::i))I)ITTTTTTTTTTIIII)=+'           ");
            Console.SetCursorPosition(23, 26);
            Console.Write("                          ::=i)))iIITTTTTTTTIIIII)=+            ");
            Console.SetCursorPosition(23, 27);
            Console.Write("                            )i)iIIIITIIITIIII))i+:'             ");
            Console.SetCursorPosition(23, 28);
            Console.Write("                               `:i)))IIIII)ii+'                ");
            System.Threading.Thread.Sleep(300);
            Console.SetCursorPosition(23, 7);
            Console.Write("                              +`:i)))IIIII)ii+  ");
            Console.SetCursorPosition(23, 8);
            Console.Write("                            )i)iIIIITIIITIIII))i+:'  ");
            Console.SetCursorPosition(23, 9);
            Console.Write("                          +:=i)))iIITTTTTTTTIIIII)=+   ");
            Console.SetCursorPosition(23, 10);
            Console.Write("                        'ii++::i))I)ITTTTTTTTTTIIII)=+'  ");
            Console.SetCursorPosition(23, 11);
            Console.Write("                       ,+)IIITI+:+i)I))TTTTLLTTTTTII))=,    ");
            Console.SetCursorPosition(23, 12);
            Console.Write("                      ;=)ITTTTLTTI=:i))I)TTTLLLTTTTTII)i;    ");
            Console.SetCursorPosition(23, 13);
            Console.Write("                     ;:)IITTLLTLLLLT=;+i)I)ITTTTLTTTII))i;    ");
            Console.SetCursorPosition(23, 14);
            Console.Write("                    ;ii)))IITTLLLLLLLLT=:i)II)TTTTLTTIII)i;    ");
            Console.SetCursorPosition(23, 15);
            Console.Write("                   'i=i)IIIIIITTLLLLLLHLL=:i)II)TTTTTTIII)i'    ");
            Console.SetCursorPosition(23, 16);
            Console.Write("                   +i.i)IIITTTTITTLLLHHLLLL);=)II)ITTTTII)i+    ");
            Console.SetCursorPosition(23, 17);
            Console.Write("                   'i=i)IIIIIITTLLLLLLHLL=:i)II)TTTTTTIII)i'     ");
            Console.SetCursorPosition(23, 18);
            Console.Write("                    ;ii)))IITTLLLLLLLLT=:i)II)TTTTLTTIII)i;        ");
            Console.SetCursorPosition(23, 19);
            Console.Write("                     ;i)IITTLLTLLLLT=;+i)I)ITTTTLTTTII))i;              ");
            Console.SetCursorPosition(23, 20);
            Console.Write("                      ;=)ITTTTLTTI=:i))I)TTTLLLTTTTTII)i;           ");
            Console.SetCursorPosition(23, 21);
            Console.Write("                       i+)IIITI+:+i)I))TTTTLLTTTTTII))=,                ");
            Console.SetCursorPosition(23, 22);
            Console.Write("                        i,i++::i))I)ITTTTTTTTTTIIII)=+'                ");
            Console.SetCursorPosition(23, 23);
            Console.Write("                          ::=i)))iIITTTTTTTTIIIII)=+                      ");
            Console.SetCursorPosition(23, 24);
            Console.Write("                            )i)iIIIITIIITIIII))i+:'                        ");
            Console.SetCursorPosition(23, 25);
            Console.Write("                               `:i)))IIIII)ii+'         ");
            Console.SetCursorPosition(23, 26);
            Console.Write("                                                                        ");
            Console.SetCursorPosition(23, 27);
            Console.Write("                                                                        ");
            Console.SetCursorPosition(23, 28);
            Console.Write("                                                                        ");
            Console.ForegroundColor = ConsoleColor.Blue;
            ClearInputViewer();
            Console.SetCursorPosition(24, 37);
            Console.Write("Welcome To Mars.  Please proceed to the mineral depot to sell your goods.");
            Console.SetCursorPosition(24, 39);
            Console.Write("We also offer a wide range of ship upgrades available in the ship upgrade ");
            Console.SetCursorPosition(24, 40);
            Console.Write("facility!  We have scanners that increase your chance of finding specific");
            Console.SetCursorPosition(24, 41);
            Console.Write("minerals, mining lasers that increase mining returns, and general weapons");
            Console.SetCursorPosition(24, 42);
            Console.Write("upgrades!  Press <ENTER> to land...");
            Console.ReadKey();
        }

        public void DisplayVenus()
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            ClearMainViewer();
            Console.SetCursorPosition(23, 28);
            Console.Write("                              +`:i)))IIIII)ii+'   ");
            System.Threading.Thread.Sleep(300);
            Console.SetCursorPosition(23, 26);
            Console.Write("                              +`:i)))IIIII)ii+   ");
            Console.SetCursorPosition(23, 27);
            Console.Write("                            )i)iIIIITIIITIIII))i+:' ");
            Console.SetCursorPosition(23, 28);
            Console.Write("                          +:=i)))iIITTTTTTTTIIIII)=+   ");
            System.Threading.Thread.Sleep(300);
            Console.SetCursorPosition(23, 24);
            Console.Write("                              +`:i)))IIIII)ii+   ");
            Console.SetCursorPosition(23, 25);
            Console.Write("                            )i)iIIIITIIITIIII))i+:'   ");
            Console.SetCursorPosition(23, 26);
            Console.Write("                          +:=i)))iIITTTTTTTTIIIII)=+    ");
            Console.SetCursorPosition(23, 27);
            Console.Write("                        'ii++::i))I)ITTTTTTTTTTIIII)=+'   ");
            Console.SetCursorPosition(23, 28);
            Console.Write("                       ,+)IIITI+:+i)I))TTTTLLTTTTTII))=,   ");
            System.Threading.Thread.Sleep(300);
            Console.SetCursorPosition(23, 22);
            Console.Write("                              +`:i)))IIIII)ii+   ");
            Console.SetCursorPosition(23, 23);
            Console.Write("                            )i)iIIIITIIITIIII))i+:'   ");
            Console.SetCursorPosition(23, 24);
            Console.Write("                          +:=i)))iIITTTTTTTTIIIII)=+   ");
            Console.SetCursorPosition(23, 25);
            Console.Write("                        'ii++::i))I)ITTTTTTTTTTIIII)=+'   ");
            Console.SetCursorPosition(23, 26);
            Console.Write("                       ,+)IIITI+:+i)I))TTTTLLTTTTTII))=,  ");
            Console.SetCursorPosition(23, 27);
            Console.Write("                      ;=)ITTTTLTTI=:i))I)TTTLLLTTTTTII)i;  ");
            Console.SetCursorPosition(23, 28);
            Console.Write("                     ;:)IITTLLTLLLLT=;+i)I)ITTTTLTTTII))i;  ");
            System.Threading.Thread.Sleep(300);
            Console.SetCursorPosition(23, 20);
            Console.Write("                              +`:i)))IIIII)ii+   ");
            Console.SetCursorPosition(23, 21);
            Console.Write("                            )i)iIIIITIIITIIII))i+:'   ");
            Console.SetCursorPosition(23, 22);
            Console.Write("                          +:=i)))iIITTTTTTTTIIIII)=+  ");
            Console.SetCursorPosition(23, 23);
            Console.Write("                        'ii++::i))I)ITTTTTTTTTTIIII)=+'  ");
            Console.SetCursorPosition(23, 24);
            Console.Write("                       ,+)IIITI+:+i)I))TTTTLLTTTTTII))=,  ");
            Console.SetCursorPosition(23, 25);
            Console.Write("                      ;=)ITTTTLTTI=:i))I)TTTLLLTTTTTII)i;  ");
            Console.SetCursorPosition(23, 26);
            Console.Write("                     ;:)IITTLLTLLLLT=;+i)I)ITTTTLTTTII))i;  ");
            Console.SetCursorPosition(23, 27);
            Console.Write("                    ;ii)))IITTLLLLLLLLT=:i)II)TTTTLTTIII)i;  ");
            Console.SetCursorPosition(23, 28);
            Console.Write("                   'i=i)IIIIIITTLLLLLLHLL=:i)II)TTTTTTIII)i'  ");
            System.Threading.Thread.Sleep(300);
            Console.SetCursorPosition(23, 18);
            Console.Write("                              +`:i)))IIIII)ii+   ");
            Console.SetCursorPosition(23, 19);
            Console.Write("                            )i)iIIIITIIITIIII))i+:'   ");
            Console.SetCursorPosition(23, 20);
            Console.Write("                          +:=i)))iIITTTTTTTTIIIII)=+  ");
            Console.SetCursorPosition(23, 21);
            Console.Write("                        'ii++::i))I)ITTTTTTTTTTIIII)=+'  ");
            Console.SetCursorPosition(23, 22);
            Console.Write("                       ,+)IIITI+:+i)I))TTTTLLTTTTTII))=,  ");
            Console.SetCursorPosition(23, 23);
            Console.Write("                      ;=)ITTTTLTTI=:i))I)TTTLLLTTTTTII)i; ");
            Console.SetCursorPosition(23, 24);
            Console.Write("                     ;:)IITTLLTLLLLT=;+i)I)ITTTTLTTTII))i;  ");
            Console.SetCursorPosition(23, 25);
            Console.Write("                    ;ii)))IITTLLLLLLLLT=:i)II)TTTTLTTIII)i;  ");
            Console.SetCursorPosition(23, 26);
            Console.Write("                   'i=i)IIIIIITTLLLLLLHLL=:i)II)TTTTTTIII)i'  ");
            Console.SetCursorPosition(23, 27);
            Console.Write("                   +i.i)IIITTTTITTLLLHHLLLL);=)II)ITTTTII)i+    ");
            Console.SetCursorPosition(23, 28);
            Console.Write("                   'i=i)IIIIIITTLLLLLLHLL=:i)II)TTTTTTIII)i'  ");
            System.Threading.Thread.Sleep(300);
            Console.SetCursorPosition(23, 16);
            Console.Write("                              +`:i)))IIIII)ii+   ");
            Console.SetCursorPosition(23, 17);
            Console.Write("                            )i)iIIIITIIITIIII))i+:'  ");
            Console.SetCursorPosition(23, 18);
            Console.Write("                          +:=i)))iIITTTTTTTTIIIII)=+  ");
            Console.SetCursorPosition(23, 19);
            Console.Write("                        'ii++::i))I)ITTTTTTTTTTIIII)=+'   ");
            Console.SetCursorPosition(23, 20);
            Console.Write("                       ,+)IIITI+:+i)I))TTTTLLTTTTTII))=,  ");
            Console.SetCursorPosition(23, 21);
            Console.Write("                      ;=)ITTTTLTTI=:i))I)TTTLLLTTTTTII)i;  ");
            Console.SetCursorPosition(23, 22);
            Console.Write("                     ;:)IITTLLTLLLLT=;+i)I)ITTTTLTTTII))i;  ");
            Console.SetCursorPosition(23, 23);
            Console.Write("                    ;ii)))IITTLLLLLLLLT=:i)II)TTTTLTTIII)i;   ");
            Console.SetCursorPosition(23, 24);
            Console.Write("                   'i=i)IIIIIITTLLLLLLHLL=:i)II)TTTTTTIII)i'  ");
            Console.SetCursorPosition(23, 25);
            Console.Write("                   +i.i)IIITTTTITTLLLHHLLLL);=)II)ITTTTII)i+    ");
            Console.SetCursorPosition(23, 26);
            Console.Write("                   'i=i)IIIIIITTLLLLLLHLL=:i)II)TTTTTTIII)i'   ");
            Console.SetCursorPosition(23, 27);
            Console.Write("                    ;ii)))IITTLLLLLLLLT=:i)II)TTTTLTTIII)i;   ");
            Console.SetCursorPosition(23, 28);
            Console.Write("                     ;i)IITTLLTLLLLT=;+i)I)ITTTTLTTTII))i;   ");
            System.Threading.Thread.Sleep(300);
            Console.SetCursorPosition(23, 14);
            Console.Write("                              +`:i)))IIIII)ii+   ");
            Console.SetCursorPosition(23, 15);
            Console.Write("                            )i)iIIIITIIITIIII))i+:'   ");
            Console.SetCursorPosition(23, 16);
            Console.Write("                          +:=i)))iIITTTTTTTTIIIII)=+   ");
            Console.SetCursorPosition(23, 17);
            Console.Write("                        'ii++::i))I)ITTTTTTTTTTIIII)=+'   ");
            Console.SetCursorPosition(23, 18);
            Console.Write("                       ,+)IIITI+:+i)I))TTTTLLTTTTTII))=,   ");
            Console.SetCursorPosition(23, 19);
            Console.Write("                      ;=)ITTTTLTTI=:i))I)TTTLLLTTTTTII)i;   ");
            Console.SetCursorPosition(23, 20);
            Console.Write("                     ;:)IITTLLTLLLLT=;+i)I)ITTTTLTTTII))i;   ");
            Console.SetCursorPosition(23, 21);
            Console.Write("                    ;ii)))IITTLLLLLLLLT=:i)II)TTTTLTTIII)i;   ");
            Console.SetCursorPosition(23, 22);
            Console.Write("                   'i=i)IIIIIITTLLLLLLHLL=:i)II)TTTTTTIII)i'  ");
            Console.SetCursorPosition(23, 23);
            Console.Write("                   +i.i)IIITTTTITTLLLHHLLLL);=)II)ITTTTII)i+    ");
            Console.SetCursorPosition(23, 24);
            Console.Write("                   'i=i)IIIIIITTLLLLLLHLL=:i)II)TTTTTTIII)i'    ");
            Console.SetCursorPosition(23, 25);
            Console.Write("                    ;ii)))IITTLLLLLLLLT=:i)II)TTTTLTTIII)i;    ");
            Console.SetCursorPosition(23, 26);
            Console.Write("                     ;i)IITTLLTLLLLT=;+i)I)ITTTTLTTTII))i;     ");
            Console.SetCursorPosition(23, 27);
            Console.Write("                      ;=)ITTTTLTTI=:i))I)TTTLLLTTTTTII)i;    ");
            Console.SetCursorPosition(23, 28);
            System.Threading.Thread.Sleep(300);
            Console.SetCursorPosition(23, 12);
            Console.Write("                              +`:i)))IIIII)ii+    ");
            Console.SetCursorPosition(23, 13);
            Console.Write("                            )i)iIIIITIIITIIII))i+:'   ");
            Console.SetCursorPosition(23, 14);
            Console.Write("                          +:=i)))iIITTTTTTTTIIIII)=+   ");
            Console.SetCursorPosition(23, 15);
            Console.Write("                        'ii++::i))I)ITTTTTTTTTTIIII)=+'  ");
            Console.SetCursorPosition(23, 16);
            Console.Write("                       ,+)IIITI+:+i)I))TTTTLLTTTTTII))=,  ");
            Console.SetCursorPosition(23, 17);
            Console.Write("                      ;=)ITTTTLTTI=:i))I)TTTLLLTTTTTII)i;  ");
            Console.SetCursorPosition(23, 18);
            Console.Write("                     ;:)IITTLLTLLLLT=;+i)I)ITTTTLTTTII))i;  ");
            Console.SetCursorPosition(23, 19);
            Console.Write("                    ;ii)))IITTLLLLLLLLT=:i)II)TTTTLTTIII)i;  ");
            Console.SetCursorPosition(23, 20);
            Console.Write("                   'i=i)IIIIIITTLLLLLLHLL=:i)II)TTTTTTIII)i'  ");
            Console.SetCursorPosition(23, 21);
            Console.Write("                   +i.i)IIITTTTITTLLLHHLLLL);=)II)ITTTTII)i+   ");
            Console.SetCursorPosition(23, 22);
            Console.Write("                   'i=i)IIIIIITTLLLLLLHLL=:i)II)TTTTTTIII)i'  ");
            Console.SetCursorPosition(23, 23);
            Console.Write("                    ;ii)))IITTLLLLLLLLT=:i)II)TTTTLTTIII)i;    ");
            Console.SetCursorPosition(23, 24);
            Console.Write("                     ;i)IITTLLTLLLLT=;+i)I)ITTTTLTTTII))i;      ");
            Console.SetCursorPosition(23, 25);
            Console.Write("                      ;=)ITTTTLTTI=:i))I)TTTLLLTTTTTII)i;        ");
            Console.SetCursorPosition(23, 26);
            Console.Write("                       i+)IIITI+:+i)I))TTTTLLTTTTTII))=,         ");
            Console.SetCursorPosition(23, 27);
            Console.Write("                        i,i++::i))I)ITTTTTTTTTTIIII)=+'           ");
            Console.SetCursorPosition(23, 28);
            Console.Write("                          ::=i)))iIITTTTTTTTIIIII)=+            ");
            System.Threading.Thread.Sleep(300);
            Console.SetCursorPosition(23, 10);
            Console.Write("                              +`:i)))IIIII)ii+   ");
            Console.SetCursorPosition(23, 11);
            Console.Write("                            )i)iIIIITIIITIIII))i+:'   ");
            Console.SetCursorPosition(23, 12);
            Console.Write("                          +:=i)))iIITTTTTTTTIIIII)=+   ");
            Console.SetCursorPosition(23, 13);
            Console.Write("                        'ii++::i))I)ITTTTTTTTTTIIII)=+'  ");
            Console.SetCursorPosition(23, 14);
            Console.Write("                       ,+)IIITI+:+i)I))TTTTLLTTTTTII))=,   ");
            Console.SetCursorPosition(23, 15);
            Console.Write("                      ;=)ITTTTLTTI=:i))I)TTTLLLTTTTTII)i;   ");
            Console.SetCursorPosition(23, 16);
            Console.Write("                     ;:)IITTLLTLLLLT=;+i)I)ITTTTLTTTII))i;   ");
            Console.SetCursorPosition(23, 17);
            Console.Write("                    ;ii)))IITTLLLLLLLLT=:i)II)TTTTLTTIII)i;   ");
            Console.SetCursorPosition(23, 18);
            Console.Write("                   'i=i)IIIIIITTLLLLLLHLL=:i)II)TTTTTTIII)i'   ");
            Console.SetCursorPosition(23, 19);
            Console.Write("                   +i.i)IIITTTTITTLLLHHLLLL);=)II)ITTTTII)i+    ");
            Console.SetCursorPosition(23, 20);
            Console.Write("                   'i=i)IIIIIITTLLLLLLHLL=:i)II)TTTTTTIII)i'   ");
            Console.SetCursorPosition(23, 21);
            Console.Write("                    ;ii)))IITTLLLLLLLLT=:i)II)TTTTLTTIII)i;    ");
            Console.SetCursorPosition(23, 22);
            Console.Write("                     ;i)IITTLLTLLLLT=;+i)I)ITTTTLTTTII))i;           ");
            Console.SetCursorPosition(23, 23);
            Console.Write("                      ;=)ITTTTLTTI=:i))I)TTTLLLTTTTTII)i;        ");
            Console.SetCursorPosition(23, 24);
            Console.Write("                       i+)IIITI+:+i)I))TTTTLLTTTTTII))=,          ");
            Console.SetCursorPosition(23, 25);
            Console.Write("                        i,i++::i))I)ITTTTTTTTTTIIII)=+'           ");
            Console.SetCursorPosition(23, 26);
            Console.Write("                          ::=i)))iIITTTTTTTTIIIII)=+            ");
            Console.SetCursorPosition(23, 27);
            Console.Write("                            )i)iIIIITIIITIIII))i+:'             ");
            Console.SetCursorPosition(23, 28);
            Console.Write("                               `:i)))IIIII)ii+'                ");
            System.Threading.Thread.Sleep(300);
            Console.SetCursorPosition(23, 7);
            Console.Write("                              +`:i)))IIIII)ii+  ");
            Console.SetCursorPosition(23, 8);
            Console.Write("                            )i)iIIIITIIITIIII))i+:'  ");
            Console.SetCursorPosition(23, 9);
            Console.Write("                          +:=i)))iIITTTTTTTTIIIII)=+   ");
            Console.SetCursorPosition(23, 10);
            Console.Write("                        'ii++::i))I)ITTTTTTTTTTIIII)=+'  ");
            Console.SetCursorPosition(23, 11);
            Console.Write("                       ,+)IIITI+:+i)I))TTTTLLTTTTTII))=,    ");
            Console.SetCursorPosition(23, 12);
            Console.Write("                      ;=)ITTTTLTTI=:i))I)TTTLLLTTTTTII)i;    ");
            Console.SetCursorPosition(23, 13);
            Console.Write("                     ;:)IITTLLTLLLLT=;+i)I)ITTTTLTTTII))i;    ");
            Console.SetCursorPosition(23, 14);
            Console.Write("                    ;ii)))IITTLLLLLLLLT=:i)II)TTTTLTTIII)i;    ");
            Console.SetCursorPosition(23, 15);
            Console.Write("                   'i=i)IIIIIITTLLLLLLHLL=:i)II)TTTTTTIII)i'    ");
            Console.SetCursorPosition(23, 16);
            Console.Write("                   +i.i)IIITTTTITTLLLHHLLLL);=)II)ITTTTII)i+    ");
            Console.SetCursorPosition(23, 17);
            Console.Write("                   'i=i)IIIIIITTLLLLLLHLL=:i)II)TTTTTTIII)i'     ");
            Console.SetCursorPosition(23, 18);
            Console.Write("                    ;ii)))IITTLLLLLLLLT=:i)II)TTTTLTTIII)i;        ");
            Console.SetCursorPosition(23, 19);
            Console.Write("                     ;i)IITTLLTLLLLT=;+i)I)ITTTTLTTTII))i;              ");
            Console.SetCursorPosition(23, 20);
            Console.Write("                      ;=)ITTTTLTTI=:i))I)TTTLLLTTTTTII)i;           ");
            Console.SetCursorPosition(23, 21);
            Console.Write("                       i+)IIITI+:+i)I))TTTTLLTTTTTII))=,                ");
            Console.SetCursorPosition(23, 22);
            Console.Write("                        i,i++::i))I)ITTTTTTTTTTIIII)=+'                ");
            Console.SetCursorPosition(23, 23);
            Console.Write("                          ::=i)))iIITTTTTTTTIIIII)=+                      ");
            Console.SetCursorPosition(23, 24);
            Console.Write("                            )i)iIIIITIIITIIII))i+:'                        ");
            Console.SetCursorPosition(23, 25);
            Console.Write("                               `:i)))IIIII)ii+'         ");
            Console.SetCursorPosition(23, 26);
            Console.Write("                                                                        ");
            Console.SetCursorPosition(23, 27);
            Console.Write("                                                                        ");
            Console.SetCursorPosition(23, 28);
            Console.Write("                                                                        ");
            Console.ForegroundColor = ConsoleColor.Blue;
            ClearInputViewer();
            Console.SetCursorPosition(24, 37);
            Console.Write("Welcome To Venus!  Please proceed to the mineral depot to sell your goods.");
            Console.SetCursorPosition(24, 39);
            Console.Write("We also offer a wide range of ship upgrades available in the ship upgrade ");
            Console.SetCursorPosition(24, 40);
            Console.Write("facility!  We have scanners that increase your chance of finding specific");
            Console.SetCursorPosition(24, 41);
            Console.Write("minerals, mining lasers that increase mining returns, and general weapons");
            Console.SetCursorPosition(24, 42);
            Console.Write("upgrades!  Press <ENTER> to land...");
            Console.ReadKey();
        }

        public void DisplayMercury()
        {
            Console.ForegroundColor = ConsoleColor.Gray;
            ClearMainViewer();
            Console.SetCursorPosition(23, 28);
            Console.Write("                              +`:i)))IIIII)ii+'   ");
            System.Threading.Thread.Sleep(300);
            Console.SetCursorPosition(23, 26);
            Console.Write("                              +`:i)))IIIII)ii+   ");
            Console.SetCursorPosition(23, 27);
            Console.Write("                            )i)iIIIITIIITIIII))i+:' ");
            Console.SetCursorPosition(23, 28);
            Console.Write("                          +:=i)))iIITTTTTTTTIIIII)=+   ");
            System.Threading.Thread.Sleep(300);
            Console.SetCursorPosition(23, 24);
            Console.Write("                              +`:i)))IIIII)ii+   ");
            Console.SetCursorPosition(23, 25);
            Console.Write("                            )i)iIIIITIIITIIII))i+:'   ");
            Console.SetCursorPosition(23, 26);
            Console.Write("                          +:=i)))iIITTTTTTTTIIIII)=+    ");
            Console.SetCursorPosition(23, 27);
            Console.Write("                        'ii++::i))I)ITTTTTTTTTTIIII)=+'   ");
            Console.SetCursorPosition(23, 28);
            Console.Write("                       ,+)IIITI+:+i)I))TTTTLLTTTTTII))=,   ");
            System.Threading.Thread.Sleep(300);
            Console.SetCursorPosition(23, 22);
            Console.Write("                              +`:i)))IIIII)ii+   ");
            Console.SetCursorPosition(23, 23);
            Console.Write("                            )i)iIIIITIIITIIII))i+:'   ");
            Console.SetCursorPosition(23, 24);
            Console.Write("                          +:=i)))iIITTTTTTTTIIIII)=+   ");
            Console.SetCursorPosition(23, 25);
            Console.Write("                        'ii++::i))I)ITTTTTTTTTTIIII)=+'   ");
            Console.SetCursorPosition(23, 26);
            Console.Write("                       ,+)IIITI+:+i)I))TTTTLLTTTTTII))=,  ");
            Console.SetCursorPosition(23, 27);
            Console.Write("                      ;=)ITTTTLTTI=:i))I)TTTLLLTTTTTII)i;  ");
            Console.SetCursorPosition(23, 28);
            Console.Write("                     ;:)IITTLLTLLLLT=;+i)I)ITTTTLTTTII))i;  ");
            System.Threading.Thread.Sleep(300);
            Console.SetCursorPosition(23, 20);
            Console.Write("                              +`:i)))IIIII)ii+   ");
            Console.SetCursorPosition(23, 21);
            Console.Write("                            )i)iIIIITIIITIIII))i+:'   ");
            Console.SetCursorPosition(23, 22);
            Console.Write("                          +:=i)))iIITTTTTTTTIIIII)=+  ");
            Console.SetCursorPosition(23, 23);
            Console.Write("                        'ii++::i))I)ITTTTTTTTTTIIII)=+'  ");
            Console.SetCursorPosition(23, 24);
            Console.Write("                       ,+)IIITI+:+i)I))TTTTLLTTTTTII))=,  ");
            Console.SetCursorPosition(23, 25);
            Console.Write("                      ;=)ITTTTLTTI=:i))I)TTTLLLTTTTTII)i;  ");
            Console.SetCursorPosition(23, 26);
            Console.Write("                     ;:)IITTLLTLLLLT=;+i)I)ITTTTLTTTII))i;  ");
            Console.SetCursorPosition(23, 27);
            Console.Write("                    ;ii)))IITTLLLLLLLLT=:i)II)TTTTLTTIII)i;  ");
            Console.SetCursorPosition(23, 28);
            Console.Write("                   'i=i)IIIIIITTLLLLLLHLL=:i)II)TTTTTTIII)i'  ");
            System.Threading.Thread.Sleep(300);
            Console.SetCursorPosition(23, 18);
            Console.Write("                              +`:i)))IIIII)ii+   ");
            Console.SetCursorPosition(23, 19);
            Console.Write("                            )i)iIIIITIIITIIII))i+:'   ");
            Console.SetCursorPosition(23, 20);
            Console.Write("                          +:=i)))iIITTTTTTTTIIIII)=+  ");
            Console.SetCursorPosition(23, 21);
            Console.Write("                        'ii++::i))I)ITTTTTTTTTTIIII)=+'  ");
            Console.SetCursorPosition(23, 22);
            Console.Write("                       ,+)IIITI+:+i)I))TTTTLLTTTTTII))=,  ");
            Console.SetCursorPosition(23, 23);
            Console.Write("                      ;=)ITTTTLTTI=:i))I)TTTLLLTTTTTII)i; ");
            Console.SetCursorPosition(23, 24);
            Console.Write("                     ;:)IITTLLTLLLLT=;+i)I)ITTTTLTTTII))i;  ");
            Console.SetCursorPosition(23, 25);
            Console.Write("                    ;ii)))IITTLLLLLLLLT=:i)II)TTTTLTTIII)i;  ");
            Console.SetCursorPosition(23, 26);
            Console.Write("                   'i=i)IIIIIITTLLLLLLHLL=:i)II)TTTTTTIII)i'  ");
            Console.SetCursorPosition(23, 27);
            Console.Write("                   +i.i)IIITTTTITTLLLHHLLLL);=)II)ITTTTII)i+    ");
            Console.SetCursorPosition(23, 28);
            Console.Write("                   'i=i)IIIIIITTLLLLLLHLL=:i)II)TTTTTTIII)i'  ");
            System.Threading.Thread.Sleep(300);
            Console.SetCursorPosition(23, 16);
            Console.Write("                              +`:i)))IIIII)ii+   ");
            Console.SetCursorPosition(23, 17);
            Console.Write("                            )i)iIIIITIIITIIII))i+:'  ");
            Console.SetCursorPosition(23, 18);
            Console.Write("                          +:=i)))iIITTTTTTTTIIIII)=+  ");
            Console.SetCursorPosition(23, 19);
            Console.Write("                        'ii++::i))I)ITTTTTTTTTTIIII)=+'   ");
            Console.SetCursorPosition(23, 20);
            Console.Write("                       ,+)IIITI+:+i)I))TTTTLLTTTTTII))=,  ");
            Console.SetCursorPosition(23, 21);
            Console.Write("                      ;=)ITTTTLTTI=:i))I)TTTLLLTTTTTII)i;  ");
            Console.SetCursorPosition(23, 22);
            Console.Write("                     ;:)IITTLLTLLLLT=;+i)I)ITTTTLTTTII))i;  ");
            Console.SetCursorPosition(23, 23);
            Console.Write("                    ;ii)))IITTLLLLLLLLT=:i)II)TTTTLTTIII)i;   ");
            Console.SetCursorPosition(23, 24);
            Console.Write("                   'i=i)IIIIIITTLLLLLLHLL=:i)II)TTTTTTIII)i'  ");
            Console.SetCursorPosition(23, 25);
            Console.Write("                   +i.i)IIITTTTITTLLLHHLLLL);=)II)ITTTTII)i+    ");
            Console.SetCursorPosition(23, 26);
            Console.Write("                   'i=i)IIIIIITTLLLLLLHLL=:i)II)TTTTTTIII)i'   ");
            Console.SetCursorPosition(23, 27);
            Console.Write("                    ;ii)))IITTLLLLLLLLT=:i)II)TTTTLTTIII)i;   ");
            Console.SetCursorPosition(23, 28);
            Console.Write("                     ;i)IITTLLTLLLLT=;+i)I)ITTTTLTTTII))i;   ");
            System.Threading.Thread.Sleep(300);
            Console.SetCursorPosition(23, 14);
            Console.Write("                              +`:i)))IIIII)ii+   ");
            Console.SetCursorPosition(23, 15);
            Console.Write("                            )i)iIIIITIIITIIII))i+:'   ");
            Console.SetCursorPosition(23, 16);
            Console.Write("                          +:=i)))iIITTTTTTTTIIIII)=+   ");
            Console.SetCursorPosition(23, 17);
            Console.Write("                        'ii++::i))I)ITTTTTTTTTTIIII)=+'   ");
            Console.SetCursorPosition(23, 18);
            Console.Write("                       ,+)IIITI+:+i)I))TTTTLLTTTTTII))=,   ");
            Console.SetCursorPosition(23, 19);
            Console.Write("                      ;=)ITTTTLTTI=:i))I)TTTLLLTTTTTII)i;   ");
            Console.SetCursorPosition(23, 20);
            Console.Write("                     ;:)IITTLLTLLLLT=;+i)I)ITTTTLTTTII))i;   ");
            Console.SetCursorPosition(23, 21);
            Console.Write("                    ;ii)))IITTLLLLLLLLT=:i)II)TTTTLTTIII)i;   ");
            Console.SetCursorPosition(23, 22);
            Console.Write("                   'i=i)IIIIIITTLLLLLLHLL=:i)II)TTTTTTIII)i'  ");
            Console.SetCursorPosition(23, 23);
            Console.Write("                   +i.i)IIITTTTITTLLLHHLLLL);=)II)ITTTTII)i+    ");
            Console.SetCursorPosition(23, 24);
            Console.Write("                   'i=i)IIIIIITTLLLLLLHLL=:i)II)TTTTTTIII)i'    ");
            Console.SetCursorPosition(23, 25);
            Console.Write("                    ;ii)))IITTLLLLLLLLT=:i)II)TTTTLTTIII)i;    ");
            Console.SetCursorPosition(23, 26);
            Console.Write("                     ;i)IITTLLTLLLLT=;+i)I)ITTTTLTTTII))i;     ");
            Console.SetCursorPosition(23, 27);
            Console.Write("                      ;=)ITTTTLTTI=:i))I)TTTLLLTTTTTII)i;    ");
            Console.SetCursorPosition(23, 28);
            System.Threading.Thread.Sleep(300);
            Console.SetCursorPosition(23, 12);
            Console.Write("                              +`:i)))IIIII)ii+    ");
            Console.SetCursorPosition(23, 13);
            Console.Write("                            )i)iIIIITIIITIIII))i+:'   ");
            Console.SetCursorPosition(23, 14);
            Console.Write("                          +:=i)))iIITTTTTTTTIIIII)=+   ");
            Console.SetCursorPosition(23, 15);
            Console.Write("                        'ii++::i))I)ITTTTTTTTTTIIII)=+'  ");
            Console.SetCursorPosition(23, 16);
            Console.Write("                       ,+)IIITI+:+i)I))TTTTLLTTTTTII))=,  ");
            Console.SetCursorPosition(23, 17);
            Console.Write("                      ;=)ITTTTLTTI=:i))I)TTTLLLTTTTTII)i;  ");
            Console.SetCursorPosition(23, 18);
            Console.Write("                     ;:)IITTLLTLLLLT=;+i)I)ITTTTLTTTII))i;  ");
            Console.SetCursorPosition(23, 19);
            Console.Write("                    ;ii)))IITTLLLLLLLLT=:i)II)TTTTLTTIII)i;  ");
            Console.SetCursorPosition(23, 20);
            Console.Write("                   'i=i)IIIIIITTLLLLLLHLL=:i)II)TTTTTTIII)i'  ");
            Console.SetCursorPosition(23, 21);
            Console.Write("                   +i.i)IIITTTTITTLLLHHLLLL);=)II)ITTTTII)i+   ");
            Console.SetCursorPosition(23, 22);
            Console.Write("                   'i=i)IIIIIITTLLLLLLHLL=:i)II)TTTTTTIII)i'  ");
            Console.SetCursorPosition(23, 23);
            Console.Write("                    ;ii)))IITTLLLLLLLLT=:i)II)TTTTLTTIII)i;    ");
            Console.SetCursorPosition(23, 24);
            Console.Write("                     ;i)IITTLLTLLLLT=;+i)I)ITTTTLTTTII))i;      ");
            Console.SetCursorPosition(23, 25);
            Console.Write("                      ;=)ITTTTLTTI=:i))I)TTTLLLTTTTTII)i;        ");
            Console.SetCursorPosition(23, 26);
            Console.Write("                       i+)IIITI+:+i)I))TTTTLLTTTTTII))=,         ");
            Console.SetCursorPosition(23, 27);
            Console.Write("                        i,i++::i))I)ITTTTTTTTTTIIII)=+'           ");
            Console.SetCursorPosition(23, 28);
            Console.Write("                          ::=i)))iIITTTTTTTTIIIII)=+            ");
            System.Threading.Thread.Sleep(300);
            Console.SetCursorPosition(23, 10);
            Console.Write("                              +`:i)))IIIII)ii+   ");
            Console.SetCursorPosition(23, 11);
            Console.Write("                            )i)iIIIITIIITIIII))i+:'   ");
            Console.SetCursorPosition(23, 12);
            Console.Write("                          +:=i)))iIITTTTTTTTIIIII)=+   ");
            Console.SetCursorPosition(23, 13);
            Console.Write("                        'ii++::i))I)ITTTTTTTTTTIIII)=+'  ");
            Console.SetCursorPosition(23, 14);
            Console.Write("                       ,+)IIITI+:+i)I))TTTTLLTTTTTII))=,   ");
            Console.SetCursorPosition(23, 15);
            Console.Write("                      ;=)ITTTTLTTI=:i))I)TTTLLLTTTTTII)i;   ");
            Console.SetCursorPosition(23, 16);
            Console.Write("                     ;:)IITTLLTLLLLT=;+i)I)ITTTTLTTTII))i;   ");
            Console.SetCursorPosition(23, 17);
            Console.Write("                    ;ii)))IITTLLLLLLLLT=:i)II)TTTTLTTIII)i;   ");
            Console.SetCursorPosition(23, 18);
            Console.Write("                   'i=i)IIIIIITTLLLLLLHLL=:i)II)TTTTTTIII)i'   ");
            Console.SetCursorPosition(23, 19);
            Console.Write("                   +i.i)IIITTTTITTLLLHHLLLL);=)II)ITTTTII)i+    ");
            Console.SetCursorPosition(23, 20);
            Console.Write("                   'i=i)IIIIIITTLLLLLLHLL=:i)II)TTTTTTIII)i'   ");
            Console.SetCursorPosition(23, 21);
            Console.Write("                    ;ii)))IITTLLLLLLLLT=:i)II)TTTTLTTIII)i;    ");
            Console.SetCursorPosition(23, 22);
            Console.Write("                     ;i)IITTLLTLLLLT=;+i)I)ITTTTLTTTII))i;           ");
            Console.SetCursorPosition(23, 23);
            Console.Write("                      ;=)ITTTTLTTI=:i))I)TTTLLLTTTTTII)i;        ");
            Console.SetCursorPosition(23, 24);
            Console.Write("                       i+)IIITI+:+i)I))TTTTLLTTTTTII))=,          ");
            Console.SetCursorPosition(23, 25);
            Console.Write("                        i,i++::i))I)ITTTTTTTTTTIIII)=+'           ");
            Console.SetCursorPosition(23, 26);
            Console.Write("                          ::=i)))iIITTTTTTTTIIIII)=+            ");
            Console.SetCursorPosition(23, 27);
            Console.Write("                            )i)iIIIITIIITIIII))i+:'             ");
            Console.SetCursorPosition(23, 28);
            Console.Write("                               `:i)))IIIII)ii+'                ");
            System.Threading.Thread.Sleep(300);
            Console.SetCursorPosition(23, 7);
            Console.Write("                              +`:i)))IIIII)ii+  ");
            Console.SetCursorPosition(23, 8);
            Console.Write("                            )i)iIIIITIIITIIII))i+:'  ");
            Console.SetCursorPosition(23, 9);
            Console.Write("                          +:=i)))iIITTTTTTTTIIIII)=+   ");
            Console.SetCursorPosition(23, 10);
            Console.Write("                        'ii++::i))I)ITTTTTTTTTTIIII)=+'  ");
            Console.SetCursorPosition(23, 11);
            Console.Write("                       ,+)IIITI+:+i)I))TTTTLLTTTTTII))=,    ");
            Console.SetCursorPosition(23, 12);
            Console.Write("                      ;=)ITTTTLTTI=:i))I)TTTLLLTTTTTII)i;    ");
            Console.SetCursorPosition(23, 13);
            Console.Write("                     ;:)IITTLLTLLLLT=;+i)I)ITTTTLTTTII))i;    ");
            Console.SetCursorPosition(23, 14);
            Console.Write("                    ;ii)))IITTLLLLLLLLT=:i)II)TTTTLTTIII)i;    ");
            Console.SetCursorPosition(23, 15);
            Console.Write("                   'i=i)IIIIIITTLLLLLLHLL=:i)II)TTTTTTIII)i'    ");
            Console.SetCursorPosition(23, 16);
            Console.Write("                   +i.i)IIITTTTITTLLLHHLLLL);=)II)ITTTTII)i+    ");
            Console.SetCursorPosition(23, 17);
            Console.Write("                   'i=i)IIIIIITTLLLLLLHLL=:i)II)TTTTTTIII)i'     ");
            Console.SetCursorPosition(23, 18);
            Console.Write("                    ;ii)))IITTLLLLLLLLT=:i)II)TTTTLTTIII)i;        ");
            Console.SetCursorPosition(23, 19);
            Console.Write("                     ;i)IITTLLTLLLLT=;+i)I)ITTTTLTTTII))i;              ");
            Console.SetCursorPosition(23, 20);
            Console.Write("                      ;=)ITTTTLTTI=:i))I)TTTLLLTTTTTII)i;           ");
            Console.SetCursorPosition(23, 21);
            Console.Write("                       i+)IIITI+:+i)I))TTTTLLTTTTTII))=,                ");
            Console.SetCursorPosition(23, 22);
            Console.Write("                        i,i++::i))I)ITTTTTTTTTTIIII)=+'                ");
            Console.SetCursorPosition(23, 23);
            Console.Write("                          ::=i)))iIITTTTTTTTIIIII)=+                      ");
            Console.SetCursorPosition(23, 24);
            Console.Write("                            )i)iIIIITIIITIIII))i+:'                        ");
            Console.SetCursorPosition(23, 25);
            Console.Write("                               `:i)))IIIII)ii+'         ");
            Console.SetCursorPosition(23, 26);
            Console.Write("                                                                        ");
            Console.SetCursorPosition(23, 27);
            Console.Write("                                                                        ");
            Console.SetCursorPosition(23, 28);
            Console.Write("                                                                        ");
            Console.ForegroundColor = ConsoleColor.Blue;
            ClearInputViewer();
            Console.SetCursorPosition(24, 37);
            Console.Write("Welcome To Mercury!  Please proceed to the mineral depot to sell your goods.");
            Console.SetCursorPosition(24, 39);
            Console.Write("We also offer a wide range of ship upgrades available in the ship upgrade ");
            Console.SetCursorPosition(24, 40);
            Console.Write("facility!  We have scanners that increase your chance of finding specific");
            Console.SetCursorPosition(24, 41);
            Console.Write("minerals, mining lasers that increase mining returns, and general weapons");
            Console.SetCursorPosition(24, 42);
            Console.Write("upgrades!  Press <ENTER> to land...");
            Console.ReadKey();
        }

        public void DisplayPluto()
        {
            Console.ForegroundColor = ConsoleColor.DarkGray;
            ClearMainViewer();
            Console.SetCursorPosition(23, 28);
            Console.Write("                              +`:i)))IIIII)ii+'   ");
            System.Threading.Thread.Sleep(300);
            Console.SetCursorPosition(23, 26);
            Console.Write("                              +`:i)))IIIII)ii+   ");
            Console.SetCursorPosition(23, 27);
            Console.Write("                            )i)iIIIITIIITIIII))i+:' ");
            Console.SetCursorPosition(23, 28);
            Console.Write("                          +:=i)))iIITTTTTTTTIIIII)=+   ");
            System.Threading.Thread.Sleep(300);
            Console.SetCursorPosition(23, 24);
            Console.Write("                              +`:i)))IIIII)ii+   ");
            Console.SetCursorPosition(23, 25);
            Console.Write("                            )i)iIIIITIIITIIII))i+:'   ");
            Console.SetCursorPosition(23, 26);
            Console.Write("                          +:=i)))iIITTTTTTTTIIIII)=+    ");
            Console.SetCursorPosition(23, 27);
            Console.Write("                        'ii++::i))I)ITTTTTTTTTTIIII)=+'   ");
            Console.SetCursorPosition(23, 28);
            Console.Write("                       ,+)IIITI+:+i)I))TTTTLLTTTTTII))=,   ");
            System.Threading.Thread.Sleep(300);
            Console.SetCursorPosition(23, 22);
            Console.Write("                              +`:i)))IIIII)ii+   ");
            Console.SetCursorPosition(23, 23);
            Console.Write("                            )i)iIIIITIIITIIII))i+:'   ");
            Console.SetCursorPosition(23, 24);
            Console.Write("                          +:=i)))iIITTTTTTTTIIIII)=+   ");
            Console.SetCursorPosition(23, 25);
            Console.Write("                        'ii++::i))I)ITTTTTTTTTTIIII)=+'   ");
            Console.SetCursorPosition(23, 26);
            Console.Write("                       ,+)IIITI+:+i)I))TTTTLLTTTTTII))=,  ");
            Console.SetCursorPosition(23, 27);
            Console.Write("                      ;=)ITTTTLTTI=:i))I)TTTLLLTTTTTII)i;  ");
            Console.SetCursorPosition(23, 28);
            Console.Write("                     ;:)IITTLLTLLLLT=;+i)I)ITTTTLTTTII))i;  ");
            System.Threading.Thread.Sleep(300);
            Console.SetCursorPosition(23, 20);
            Console.Write("                              +`:i)))IIIII)ii+   ");
            Console.SetCursorPosition(23, 21);
            Console.Write("                            )i)iIIIITIIITIIII))i+:'   ");
            Console.SetCursorPosition(23, 22);
            Console.Write("                          +:=i)))iIITTTTTTTTIIIII)=+  ");
            Console.SetCursorPosition(23, 23);
            Console.Write("                        'ii++::i))I)ITTTTTTTTTTIIII)=+'  ");
            Console.SetCursorPosition(23, 24);
            Console.Write("                       ,+)IIITI+:+i)I))TTTTLLTTTTTII))=,  ");
            Console.SetCursorPosition(23, 25);
            Console.Write("                      ;=)ITTTTLTTI=:i))I)TTTLLLTTTTTII)i;  ");
            Console.SetCursorPosition(23, 26);
            Console.Write("                     ;:)IITTLLTLLLLT=;+i)I)ITTTTLTTTII))i;  ");
            Console.SetCursorPosition(23, 27);
            Console.Write("                    ;ii)))IITTLLLLLLLLT=:i)II)TTTTLTTIII)i;  ");
            Console.SetCursorPosition(23, 28);
            Console.Write("                   'i=i)IIIIIITTLLLLLLHLL=:i)II)TTTTTTIII)i'  ");
            System.Threading.Thread.Sleep(300);
            Console.SetCursorPosition(23, 18);
            Console.Write("                              +`:i)))IIIII)ii+   ");
            Console.SetCursorPosition(23, 19);
            Console.Write("                            )i)iIIIITIIITIIII))i+:'   ");
            Console.SetCursorPosition(23, 20);
            Console.Write("                          +:=i)))iIITTTTTTTTIIIII)=+  ");
            Console.SetCursorPosition(23, 21);
            Console.Write("                        'ii++::i))I)ITTTTTTTTTTIIII)=+'  ");
            Console.SetCursorPosition(23, 22);
            Console.Write("                       ,+)IIITI+:+i)I))TTTTLLTTTTTII))=,  ");
            Console.SetCursorPosition(23, 23);
            Console.Write("                      ;=)ITTTTLTTI=:i))I)TTTLLLTTTTTII)i; ");
            Console.SetCursorPosition(23, 24);
            Console.Write("                     ;:)IITTLLTLLLLT=;+i)I)ITTTTLTTTII))i;  ");
            Console.SetCursorPosition(23, 25);
            Console.Write("                    ;ii)))IITTLLLLLLLLT=:i)II)TTTTLTTIII)i;  ");
            Console.SetCursorPosition(23, 26);
            Console.Write("                   'i=i)IIIIIITTLLLLLLHLL=:i)II)TTTTTTIII)i'  ");
            Console.SetCursorPosition(23, 27);
            Console.Write("                   +i.i)IIITTTTITTLLLHHLLLL);=)II)ITTTTII)i+    ");
            Console.SetCursorPosition(23, 28);
            Console.Write("                   'i=i)IIIIIITTLLLLLLHLL=:i)II)TTTTTTIII)i'  ");
            System.Threading.Thread.Sleep(300);
            Console.SetCursorPosition(23, 16);
            Console.Write("                              +`:i)))IIIII)ii+   ");
            Console.SetCursorPosition(23, 17);
            Console.Write("                            )i)iIIIITIIITIIII))i+:'  ");
            Console.SetCursorPosition(23, 18);
            Console.Write("                          +:=i)))iIITTTTTTTTIIIII)=+  ");
            Console.SetCursorPosition(23, 19);
            Console.Write("                        'ii++::i))I)ITTTTTTTTTTIIII)=+'   ");
            Console.SetCursorPosition(23, 20);
            Console.Write("                       ,+)IIITI+:+i)I))TTTTLLTTTTTII))=,  ");
            Console.SetCursorPosition(23, 21);
            Console.Write("                      ;=)ITTTTLTTI=:i))I)TTTLLLTTTTTII)i;  ");
            Console.SetCursorPosition(23, 22);
            Console.Write("                     ;:)IITTLLTLLLLT=;+i)I)ITTTTLTTTII))i;  ");
            Console.SetCursorPosition(23, 23);
            Console.Write("                    ;ii)))IITTLLLLLLLLT=:i)II)TTTTLTTIII)i;   ");
            Console.SetCursorPosition(23, 24);
            Console.Write("                   'i=i)IIIIIITTLLLLLLHLL=:i)II)TTTTTTIII)i'  ");
            Console.SetCursorPosition(23, 25);
            Console.Write("                   +i.i)IIITTTTITTLLLHHLLLL);=)II)ITTTTII)i+    ");
            Console.SetCursorPosition(23, 26);
            Console.Write("                   'i=i)IIIIIITTLLLLLLHLL=:i)II)TTTTTTIII)i'   ");
            Console.SetCursorPosition(23, 27);
            Console.Write("                    ;ii)))IITTLLLLLLLLT=:i)II)TTTTLTTIII)i;   ");
            Console.SetCursorPosition(23, 28);
            Console.Write("                     ;i)IITTLLTLLLLT=;+i)I)ITTTTLTTTII))i;   ");
            System.Threading.Thread.Sleep(300);
            Console.SetCursorPosition(23, 14);
            Console.Write("                              +`:i)))IIIII)ii+   ");
            Console.SetCursorPosition(23, 15);
            Console.Write("                            )i)iIIIITIIITIIII))i+:'   ");
            Console.SetCursorPosition(23, 16);
            Console.Write("                          +:=i)))iIITTTTTTTTIIIII)=+   ");
            Console.SetCursorPosition(23, 17);
            Console.Write("                        'ii++::i))I)ITTTTTTTTTTIIII)=+'   ");
            Console.SetCursorPosition(23, 18);
            Console.Write("                       ,+)IIITI+:+i)I))TTTTLLTTTTTII))=,   ");
            Console.SetCursorPosition(23, 19);
            Console.Write("                      ;=)ITTTTLTTI=:i))I)TTTLLLTTTTTII)i;   ");
            Console.SetCursorPosition(23, 20);
            Console.Write("                     ;:)IITTLLTLLLLT=;+i)I)ITTTTLTTTII))i;   ");
            Console.SetCursorPosition(23, 21);
            Console.Write("                    ;ii)))IITTLLLLLLLLT=:i)II)TTTTLTTIII)i;   ");
            Console.SetCursorPosition(23, 22);
            Console.Write("                   'i=i)IIIIIITTLLLLLLHLL=:i)II)TTTTTTIII)i'  ");
            Console.SetCursorPosition(23, 23);
            Console.Write("                   +i.i)IIITTTTITTLLLHHLLLL);=)II)ITTTTII)i+    ");
            Console.SetCursorPosition(23, 24);
            Console.Write("                   'i=i)IIIIIITTLLLLLLHLL=:i)II)TTTTTTIII)i'    ");
            Console.SetCursorPosition(23, 25);
            Console.Write("                    ;ii)))IITTLLLLLLLLT=:i)II)TTTTLTTIII)i;    ");
            Console.SetCursorPosition(23, 26);
            Console.Write("                     ;i)IITTLLTLLLLT=;+i)I)ITTTTLTTTII))i;     ");
            Console.SetCursorPosition(23, 27);
            Console.Write("                      ;=)ITTTTLTTI=:i))I)TTTLLLTTTTTII)i;    ");
            Console.SetCursorPosition(23, 28);
            System.Threading.Thread.Sleep(300);
            Console.SetCursorPosition(23, 12);
            Console.Write("                              +`:i)))IIIII)ii+    ");
            Console.SetCursorPosition(23, 13);
            Console.Write("                            )i)iIIIITIIITIIII))i+:'   ");
            Console.SetCursorPosition(23, 14);
            Console.Write("                          +:=i)))iIITTTTTTTTIIIII)=+   ");
            Console.SetCursorPosition(23, 15);
            Console.Write("                        'ii++::i))I)ITTTTTTTTTTIIII)=+'  ");
            Console.SetCursorPosition(23, 16);
            Console.Write("                       ,+)IIITI+:+i)I))TTTTLLTTTTTII))=,  ");
            Console.SetCursorPosition(23, 17);
            Console.Write("                      ;=)ITTTTLTTI=:i))I)TTTLLLTTTTTII)i;  ");
            Console.SetCursorPosition(23, 18);
            Console.Write("                     ;:)IITTLLTLLLLT=;+i)I)ITTTTLTTTII))i;  ");
            Console.SetCursorPosition(23, 19);
            Console.Write("                    ;ii)))IITTLLLLLLLLT=:i)II)TTTTLTTIII)i;  ");
            Console.SetCursorPosition(23, 20);
            Console.Write("                   'i=i)IIIIIITTLLLLLLHLL=:i)II)TTTTTTIII)i'  ");
            Console.SetCursorPosition(23, 21);
            Console.Write("                   +i.i)IIITTTTITTLLLHHLLLL);=)II)ITTTTII)i+   ");
            Console.SetCursorPosition(23, 22);
            Console.Write("                   'i=i)IIIIIITTLLLLLLHLL=:i)II)TTTTTTIII)i'  ");
            Console.SetCursorPosition(23, 23);
            Console.Write("                    ;ii)))IITTLLLLLLLLT=:i)II)TTTTLTTIII)i;    ");
            Console.SetCursorPosition(23, 24);
            Console.Write("                     ;i)IITTLLTLLLLT=;+i)I)ITTTTLTTTII))i;      ");
            Console.SetCursorPosition(23, 25);
            Console.Write("                      ;=)ITTTTLTTI=:i))I)TTTLLLTTTTTII)i;        ");
            Console.SetCursorPosition(23, 26);
            Console.Write("                       i+)IIITI+:+i)I))TTTTLLTTTTTII))=,         ");
            Console.SetCursorPosition(23, 27);
            Console.Write("                        i,i++::i))I)ITTTTTTTTTTIIII)=+'           ");
            Console.SetCursorPosition(23, 28);
            Console.Write("                          ::=i)))iIITTTTTTTTIIIII)=+            ");
            System.Threading.Thread.Sleep(300);
            Console.SetCursorPosition(23, 10);
            Console.Write("                              +`:i)))IIIII)ii+   ");
            Console.SetCursorPosition(23, 11);
            Console.Write("                            )i)iIIIITIIITIIII))i+:'   ");
            Console.SetCursorPosition(23, 12);
            Console.Write("                          +:=i)))iIITTTTTTTTIIIII)=+   ");
            Console.SetCursorPosition(23, 13);
            Console.Write("                        'ii++::i))I)ITTTTTTTTTTIIII)=+'  ");
            Console.SetCursorPosition(23, 14);
            Console.Write("                       ,+)IIITI+:+i)I))TTTTLLTTTTTII))=,   ");
            Console.SetCursorPosition(23, 15);
            Console.Write("                      ;=)ITTTTLTTI=:i))I)TTTLLLTTTTTII)i;   ");
            Console.SetCursorPosition(23, 16);
            Console.Write("                     ;:)IITTLLTLLLLT=;+i)I)ITTTTLTTTII))i;   ");
            Console.SetCursorPosition(23, 17);
            Console.Write("                    ;ii)))IITTLLLLLLLLT=:i)II)TTTTLTTIII)i;   ");
            Console.SetCursorPosition(23, 18);
            Console.Write("                   'i=i)IIIIIITTLLLLLLHLL=:i)II)TTTTTTIII)i'   ");
            Console.SetCursorPosition(23, 19);
            Console.Write("                   +i.i)IIITTTTITTLLLHHLLLL);=)II)ITTTTII)i+    ");
            Console.SetCursorPosition(23, 20);
            Console.Write("                   'i=i)IIIIIITTLLLLLLHLL=:i)II)TTTTTTIII)i'   ");
            Console.SetCursorPosition(23, 21);
            Console.Write("                    ;ii)))IITTLLLLLLLLT=:i)II)TTTTLTTIII)i;    ");
            Console.SetCursorPosition(23, 22);
            Console.Write("                     ;i)IITTLLTLLLLT=;+i)I)ITTTTLTTTII))i;           ");
            Console.SetCursorPosition(23, 23);
            Console.Write("                      ;=)ITTTTLTTI=:i))I)TTTLLLTTTTTII)i;        ");
            Console.SetCursorPosition(23, 24);
            Console.Write("                       i+)IIITI+:+i)I))TTTTLLTTTTTII))=,          ");
            Console.SetCursorPosition(23, 25);
            Console.Write("                        i,i++::i))I)ITTTTTTTTTTIIII)=+'           ");
            Console.SetCursorPosition(23, 26);
            Console.Write("                          ::=i)))iIITTTTTTTTIIIII)=+            ");
            Console.SetCursorPosition(23, 27);
            Console.Write("                            )i)iIIIITIIITIIII))i+:'             ");
            Console.SetCursorPosition(23, 28);
            Console.Write("                               `:i)))IIIII)ii+'                ");
            System.Threading.Thread.Sleep(300);
            Console.SetCursorPosition(23, 7);
            Console.Write("                              +`:i)))IIIII)ii+  ");
            Console.SetCursorPosition(23, 8);
            Console.Write("                            )i)iIIIITIIITIIII))i+:'  ");
            Console.SetCursorPosition(23, 9);
            Console.Write("                          +:=i)))iIITTTTTTTTIIIII)=+   ");
            Console.SetCursorPosition(23, 10);
            Console.Write("                        'ii++::i))I)ITTTTTTTTTTIIII)=+'  ");
            Console.SetCursorPosition(23, 11);
            Console.Write("                       ,+)IIITI+:+i)I))TTTTLLTTTTTII))=,    ");
            Console.SetCursorPosition(23, 12);
            Console.Write("                      ;=)ITTTTLTTI=:i))I)TTTLLLTTTTTII)i;    ");
            Console.SetCursorPosition(23, 13);
            Console.Write("                     ;:)IITTLLTLLLLT=;+i)I)ITTTTLTTTII))i;    ");
            Console.SetCursorPosition(23, 14);
            Console.Write("                    ;ii)))IITTLLLLLLLLT=:i)II)TTTTLTTIII)i;    ");
            Console.SetCursorPosition(23, 15);
            Console.Write("                   'i=i)IIIIIITTLLLLLLHLL=:i)II)TTTTTTIII)i'    ");
            Console.SetCursorPosition(23, 16);
            Console.Write("                   +i.i)IIITTTTITTLLLHHLLLL);=)II)ITTTTII)i+    ");
            Console.SetCursorPosition(23, 17);
            Console.Write("                   'i=i)IIIIIITTLLLLLLHLL=:i)II)TTTTTTIII)i'     ");
            Console.SetCursorPosition(23, 18);
            Console.Write("                    ;ii)))IITTLLLLLLLLT=:i)II)TTTTLTTIII)i;        ");
            Console.SetCursorPosition(23, 19);
            Console.Write("                     ;i)IITTLLTLLLLT=;+i)I)ITTTTLTTTII))i;              ");
            Console.SetCursorPosition(23, 20);
            Console.Write("                      ;=)ITTTTLTTI=:i))I)TTTLLLTTTTTII)i;           ");
            Console.SetCursorPosition(23, 21);
            Console.Write("                       i+)IIITI+:+i)I))TTTTLLTTTTTII))=,                ");
            Console.SetCursorPosition(23, 22);
            Console.Write("                        i,i++::i))I)ITTTTTTTTTTIIII)=+'                ");
            Console.SetCursorPosition(23, 23);
            Console.Write("                          ::=i)))iIITTTTTTTTIIIII)=+                      ");
            Console.SetCursorPosition(23, 24);
            Console.Write("                            )i)iIIIITIIITIIII))i+:'                        ");
            Console.SetCursorPosition(23, 25);
            Console.Write("                               `:i)))IIIII)ii+'         ");
            Console.SetCursorPosition(23, 26);
            Console.Write("                                                                        ");
            Console.SetCursorPosition(23, 27);
            Console.Write("                                                                        ");
            Console.SetCursorPosition(23, 28);
            Console.Write("                                                                        ");
            Console.ForegroundColor = ConsoleColor.Blue;
            ClearInputViewer();
            Console.SetCursorPosition(24, 37);
            Console.Write("Welcome To Pluto!  Please proceed to the mineral depot to sell your goods.");
            Console.SetCursorPosition(24, 39);
            Console.Write("We also offer a wide range of ship upgrades available in the ship upgrade ");
            Console.SetCursorPosition(24, 40);
            Console.Write("facility!  We have scanners that increase your chance of finding specific");
            Console.SetCursorPosition(24, 41);
            Console.Write("minerals, mining lasers that increase mining returns, and general weapons");
            Console.SetCursorPosition(24, 42);
            Console.Write("upgrades!  Press <ENTER> to land...");
            Console.ReadKey();
        }

        public void DisplayEarth()
        {
            Console.ForegroundColor = ConsoleColor.Blue;
            ClearMainViewer();
            Console.SetCursorPosition(23, 28);
            Console.Write("                              +`:i)))IIIII)ii+'   ");
            System.Threading.Thread.Sleep(300);
            Console.SetCursorPosition(23, 26);
            Console.Write("                              +`:i)))IIIII)ii+   ");
            Console.SetCursorPosition(23, 27);
            Console.Write($"                            )"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&&&&&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("TIIII))i+:'  ");
            Console.SetCursorPosition(23, 28);
            Console.Write($"                          +:="); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&&&&&&&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("TTI"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("I)=+   ");
            System.Threading.Thread.Sleep(300);
            Console.SetCursorPosition(23, 24);
            Console.Write("                              +`:i)))IIIII)ii+   ");
            Console.SetCursorPosition(23, 25);
            Console.Write($"                            )"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&&&&&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("TIIII))i+:'  ");
            Console.SetCursorPosition(23, 26);
            Console.Write($"                          +:="); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&&&&&&&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("TTI"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("I)=+   ");
            Console.SetCursorPosition(23, 27);
            Console.Write($"                        'ii++:"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&&&&&&&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("TTT"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("II)=+'  ");
            Console.SetCursorPosition(23, 28);
            Console.Write($"                       ,+)IIITI+:"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&&&&&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("LTT"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("I))=,    ");
            System.Threading.Thread.Sleep(300);
            Console.SetCursorPosition(23, 22);
            Console.Write("                              +`:i)))IIIII)ii+   ");
            Console.SetCursorPosition(23, 23);
            Console.Write($"                            )"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&&&&&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("TIIII))i+:'  ");
            Console.SetCursorPosition(23, 24);
            Console.Write($"                          +:="); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&&&&&&&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("TTI"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("I)=+   ");
            Console.SetCursorPosition(23, 25);
            Console.Write($"                        'ii++:"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&&&&&&&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("TTT"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("II)=+'  ");
            Console.SetCursorPosition(23, 26);
            Console.Write($"                       ,+)IIITI+:"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&&&&&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("LTT"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("I))=,    ");
            Console.SetCursorPosition(23, 27);
            Console.Write($"                      ;=)ITTTTLTTI="); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&&&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("LLLTTT"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("I)i;    ");
            Console.SetCursorPosition(23, 28);
            Console.Write($"                     ;:)IITTLLTLLL"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&&&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("ITTTTLTTTII))i;    ");
            System.Threading.Thread.Sleep(300);
            Console.SetCursorPosition(23, 20);
            Console.Write("                              +`:i)))IIIII)ii+   ");
            Console.SetCursorPosition(23, 21);
            Console.Write($"                            )"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&&&&&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("TIIII))i+:'  ");
            Console.SetCursorPosition(23, 22);
            Console.Write($"                          +:="); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&&&&&&&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("TTI"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("I)=+   ");
            Console.SetCursorPosition(23, 23);
            Console.Write($"                        'ii++:"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&&&&&&&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("TTT"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("II)=+'  ");
            Console.SetCursorPosition(23, 24);
            Console.Write($"                       ,+)IIITI+:"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&&&&&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("LTT"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("I))=,    ");
            Console.SetCursorPosition(23, 25);
            Console.Write($"                      ;=)ITTTTLTTI="); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&&&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("LLLTTT"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("I)i;    ");
            Console.SetCursorPosition(23, 26);
            Console.Write($"                     ;:)IITTLLTLLL"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&&&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("ITTTTLTTTII))i;    ");
            Console.SetCursorPosition(23, 27);
            Console.Write($"                    ;ii)))IITTLLLLL"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("II)TTTTLTTIII)i;    ");
            Console.SetCursorPosition(23, 28);
            Console.Write($"                   'i=i)IIIIIITTLLLL"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("L"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("=:"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write(")II)TTTTTTIII)i'    ");
            System.Threading.Thread.Sleep(300);
            Console.SetCursorPosition(23, 18);
            Console.Write("                              +`:i)))IIIII)ii+   ");
            Console.SetCursorPosition(23, 19);
            Console.Write($"                            )"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&&&&&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("TIIII))i+:'  ");
            Console.SetCursorPosition(23, 20);
            Console.Write($"                          +:="); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&&&&&&&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("TTI"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("I)=+   ");
            Console.SetCursorPosition(23, 21);
            Console.Write($"                        'ii++:"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&&&&&&&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("TTT"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("II)=+'  ");
            Console.SetCursorPosition(23, 22);
            Console.Write($"                       ,+)IIITI+:"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&&&&&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("LTT"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("I))=,    ");
            Console.SetCursorPosition(23, 23);
            Console.Write($"                      ;=)ITTTTLTTI="); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&&&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("LLLTTT"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("I)i;    ");
            Console.SetCursorPosition(23, 24);
            Console.Write($"                     ;:)IITTLLTLLL"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&&&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("ITTTTLTTTII))i;    ");
            Console.SetCursorPosition(23, 25);
            Console.Write($"                    ;ii)))IITTLLLLL"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("II)TTTTLTTIII)i;    ");
            Console.SetCursorPosition(23, 26);
            Console.Write($"                   'i=i)IIIIIITTLLLL"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("L"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("=:"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write(")II)TTTTTTIII)i'    ");
            Console.SetCursorPosition(23, 27);
            Console.Write($"                   +i.i)IIITTTTITTLLL"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("HLLL);=)II)ITTTTII)i+    ");
            Console.SetCursorPosition(23, 28);
            Console.Write($"                   'i=i)IIIIIITTLLLLLLH"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("LL:i)II)TTTTTTIII)i'     ");
            System.Threading.Thread.Sleep(300);
            Console.SetCursorPosition(23, 16);
            Console.Write("                              +`:i)))IIIII)ii+   ");
            Console.SetCursorPosition(23, 17);
            Console.Write($"                            )"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&&&&&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("TIIII))i+:'  ");
            Console.SetCursorPosition(23, 18);
            Console.Write($"                          +:="); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&&&&&&&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("TTI"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("I)=+   ");
            Console.SetCursorPosition(23, 19);
            Console.Write($"                        'ii++:"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&&&&&&&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("TTT"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("II)=+'  ");
            Console.SetCursorPosition(23, 20);
            Console.Write($"                       ,+)IIITI+:"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&&&&&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("LTT"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("I))=,    ");
            Console.SetCursorPosition(23, 21);
            Console.Write($"                      ;=)ITTTTLTTI="); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&&&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("LLLTTT"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("I)i;    ");
            Console.SetCursorPosition(23, 22);
            Console.Write($"                     ;:)IITTLLTLLL"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&&&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("ITTTTLTTTII))i;    ");
            Console.SetCursorPosition(23, 23);
            Console.Write($"                    ;ii)))IITTLLLLL"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("II)TTTTLTTIII)i;    ");
            Console.SetCursorPosition(23, 24);
            Console.Write($"                   'i=i)IIIIIITTLLLL"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("L"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("=:"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write(")II)TTTTTTIII)i'    ");
            Console.SetCursorPosition(23, 25);
            Console.Write($"                   +i.i)IIITTTTITTLLL"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("HLLL);=)II)ITTTTII)i+    ");
            Console.SetCursorPosition(23, 26);
            Console.Write($"                   'i=i)IIIIIITTLLLLLLH"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("LL:i)II)TTTTTTIII)i'     ");
            Console.SetCursorPosition(23, 27);
            Console.Write($"                    ;ii)))IITTLLLLLLLLT="); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("I)TTTTLTTIII)i;        ");
            Console.SetCursorPosition(23, 28);
            Console.Write($"                     ;i)IITTLLTLLLLT=;+"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("TTTLTTTII))i;              ");
            System.Threading.Thread.Sleep(300);
            Console.SetCursorPosition(23, 14);
            Console.Write("                              +`:i)))IIIII)ii+   ");
            Console.SetCursorPosition(23, 15);
            Console.Write($"                            )"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&&&&&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("TIIII))i+:'  ");
            Console.SetCursorPosition(23, 16);
            Console.Write($"                          +:="); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&&&&&&&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("TTI"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("I)=+   ");
            Console.SetCursorPosition(23, 17);
            Console.Write($"                        'ii++:"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&&&&&&&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("TTT"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("II)=+'  ");
            Console.SetCursorPosition(23, 18);
            Console.Write($"                       ,+)IIITI+:"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&&&&&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("LTT"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("I))=,    ");
            Console.SetCursorPosition(23, 19);
            Console.Write($"                      ;=)ITTTTLTTI="); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&&&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("LLLTTT"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("I)i;    ");
            Console.SetCursorPosition(23, 20);
            Console.Write($"                     ;:)IITTLLTLLL"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&&&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("ITTTTLTTTII))i;    ");
            Console.SetCursorPosition(23, 21);
            Console.Write($"                    ;ii)))IITTLLLLL"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("II)TTTTLTTIII)i;    ");
            Console.SetCursorPosition(23, 22);
            Console.Write($"                   'i=i)IIIIIITTLLLL"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("L"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("=:"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write(")II)TTTTTTIII)i'    ");
            Console.SetCursorPosition(23, 23);
            Console.Write($"                   +i.i)IIITTTTITTLLL"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("HLLL);=)II)ITTTTII)i+    ");
            Console.SetCursorPosition(23, 24);
            Console.Write($"                   'i=i)IIIIIITTLLLLLLH"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("LL:i)II)TTTTTTIII)i'     ");
            Console.SetCursorPosition(23, 25);
            Console.Write($"                    ;ii)))IITTLLLLLLLLT="); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("I)TTTTLTTIII)i;        ");
            Console.SetCursorPosition(23, 26);
            Console.Write($"                     ;i)IITTLLTLLLLT=;+"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("TTTLTTTII))i;              ");
            Console.SetCursorPosition(23, 27);
            Console.Write($"                      ;=)ITTTTLTTI=:i))I"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("LLTTTTTII)i;           ");
            Console.SetCursorPosition(23, 28);
            System.Threading.Thread.Sleep(300);
            Console.SetCursorPosition(23, 12);
            Console.Write("                              +`:i)))IIIII)ii+    ");
            Console.SetCursorPosition(23, 13);
            Console.Write($"                            )"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&&&&&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("TIIII))i+:'  ");
            Console.SetCursorPosition(23, 14);
            Console.Write($"                          +:="); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&&&&&&&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("TTI"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("I)=+   ");
            Console.SetCursorPosition(23, 15);
            Console.Write($"                        'ii++:"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&&&&&&&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("TTT"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("II)=+'  ");
            Console.SetCursorPosition(23, 16);
            Console.Write($"                       ,+)IIITI+:"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&&&&&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("LTT"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("I))=,    ");
            Console.SetCursorPosition(23, 17);
            Console.Write($"                      ;=)ITTTTLTTI="); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&&&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("LLLTTT"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("I)i;    ");
            Console.SetCursorPosition(23, 18);
            Console.Write($"                     ;:)IITTLLTLLL"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&&&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("ITTTTLTTTII))i;    ");
            Console.SetCursorPosition(23, 19);
            Console.Write($"                    ;ii)))IITTLLLLL"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("II)TTTTLTTIII)i;    ");
            Console.SetCursorPosition(23, 20);
            Console.Write($"                   'i=i)IIIIIITTLLLL"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("L"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("=:"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write(")II)TTTTTTIII)i'    ");
            Console.SetCursorPosition(23, 21);
            Console.Write($"                   +i.i)IIITTTTITTLLL"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("HLLL);=)II)ITTTTII)i+    ");
            Console.SetCursorPosition(23, 22);
            Console.Write($"                   'i=i)IIIIIITTLLLLLLH"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("LL:i)II)TTTTTTIII)i'     ");
            Console.SetCursorPosition(23, 23);
            Console.Write($"                    ;ii)))IITTLLLLLLLLT="); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("I)TTTTLTTIII)i;        ");
            Console.SetCursorPosition(23, 24);
            Console.Write($"                     ;i)IITTLLTLLLLT=;+"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("TTTLTTTII))i;              ");
            Console.SetCursorPosition(23, 25);
            Console.Write($"                      ;=)ITTTTLTTI=:i))I"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("LLTTTTTII)i;           ");
            Console.SetCursorPosition(23, 26);
            Console.Write($"                       i+)IIITI+:+i)I))T"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("LLTTTTII))=,                ");
            Console.SetCursorPosition(23, 27);
            Console.Write($"                        i,i++::i))I)ITT"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("TTTTIIII)=+'                ");
            Console.SetCursorPosition(23, 28);
            Console.Write($"                          ::=i)))iIITTT"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("TTIIIII)=+                      ");
            System.Threading.Thread.Sleep(300);
            Console.SetCursorPosition(23, 10);
            Console.Write("                              +`:i)))IIIII)ii+   ");
            Console.SetCursorPosition(23, 11);
            Console.Write($"                            )"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&&&&&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("TIIII))i+:'  ");
            Console.SetCursorPosition(23, 12);
            Console.Write($"                          +:="); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&&&&&&&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("TTI"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("I)=+   ");
            Console.SetCursorPosition(23, 13);
            Console.Write($"                        'ii++:"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&&&&&&&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("TTT"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("II)=+'  ");
            Console.SetCursorPosition(23, 14);
            Console.Write($"                       ,+)IIITI+:"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&&&&&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("LTT"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("I))=,    ");
            Console.SetCursorPosition(23, 15);
            Console.Write($"                      ;=)ITTTTLTTI="); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&&&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("LLLTTT"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("I)i;    ");
            Console.SetCursorPosition(23, 16);
            Console.Write($"                     ;:)IITTLLTLLL"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&&&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("ITTTTLTTTII))i;    ");
            Console.SetCursorPosition(23, 17);
            Console.Write($"                    ;ii)))IITTLLLLL"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("II)TTTTLTTIII)i;    ");
            Console.SetCursorPosition(23, 18);
            Console.Write($"                   'i=i)IIIIIITTLLLL"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("L"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("=:"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write(")II)TTTTTTIII)i'    ");
            Console.SetCursorPosition(23, 19);
            Console.Write($"                   +i.i)IIITTTTITTLLL"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("HLLL);=)II)ITTTTII)i+    ");
            Console.SetCursorPosition(23, 20);
            Console.Write($"                   'i=i)IIIIIITTLLLLLLH"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("LL:i)II)TTTTTTIII)i'     ");
            Console.SetCursorPosition(23, 21);
            Console.Write($"                    ;ii)))IITTLLLLLLLLT="); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("I)TTTTLTTIII)i;        ");
            Console.SetCursorPosition(23, 22);
            Console.Write($"                     ;i)IITTLLTLLLLT=;+"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("TTTLTTTII))i;              ");
            Console.SetCursorPosition(23, 23);
            Console.Write($"                      ;=)ITTTTLTTI=:i))I"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("LLTTTTTII)i;           ");
            Console.SetCursorPosition(23, 24);
            Console.Write($"                       i+)IIITI+:+i)I))T"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("LLTTTTII))=,                ");
            Console.SetCursorPosition(23, 25);
            Console.Write($"                        i,i++::i))I)ITT"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("TTTTIIII)=+'                ");
            Console.SetCursorPosition(23, 26);
            Console.Write($"                          ::=i)))iIITTT"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("TTIIIII)=+                      ");
            Console.SetCursorPosition(23, 27);
            Console.Write($"                            )i)iIIIITII"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("TIIII))i+:'                        ");
            Console.SetCursorPosition(23, 28);
            Console.Write("                               `:i)))IIIII)ii+'                ");
            System.Threading.Thread.Sleep(300);
            Console.SetCursorPosition(23, 7);
            Console.Write($"                              +`:i)))IIIII)ii+  ");
            Console.SetCursorPosition(23, 8);
            Console.Write($"                            )"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&&&&&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("TIIII))i+:'  ");
            Console.SetCursorPosition(23, 9);
            Console.Write($"                          +:="); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&&&&&&&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("TTI"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("I)=+   ");
            Console.SetCursorPosition(23, 10);
            Console.Write($"                        'ii++:"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&&&&&&&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("TTT"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("II)=+'  ");
            Console.SetCursorPosition(23, 11);
            Console.Write($"                       ,+)IIITI+:"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&&&&&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("LTT"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("I))=,    ");
            Console.SetCursorPosition(23, 12);
            Console.Write($"                      ;=)ITTTTLTTI="); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&&&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("LLLTTT"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("I)i;    ");
            Console.SetCursorPosition(23, 13);
            Console.Write($"                     ;:)IITTLLTLLL"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&&&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("ITTTTLTTTII))i;    ");
            Console.SetCursorPosition(23, 14);
            Console.Write($"                    ;ii)))IITTLLLLL"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("II)TTTTLTTIII)i;    ");
            Console.SetCursorPosition(23, 15);
            Console.Write($"                   'i=i)IIIIIITTLLLL"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("L"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("=:"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write(")II)TTTTTTIII)i'    ");
            Console.SetCursorPosition(23, 16);
            Console.Write($"                   +i.i)IIITTTTITTLLL"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("HLLL);=)II)ITTTTII)i+    ");
            Console.SetCursorPosition(23, 17);
            Console.Write($"                   'i=i)IIIIIITTLLLLLLH"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("LL:i)II)TTTTTTIII)i'     ");
            Console.SetCursorPosition(23, 18);
            Console.Write($"                    ;ii)))IITTLLLLLLLLT="); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("I)TTTTLTTIII)i;        ");
            Console.SetCursorPosition(23, 19);
            Console.Write($"                     ;i)IITTLLTLLLLT=;+"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("TTTLTTTII))i;              ");
            Console.SetCursorPosition(23, 20);
            Console.Write($"                      ;=)ITTTTLTTI=:i))I"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("LLTTTTTII)i;           ");
            Console.SetCursorPosition(23, 21);
            Console.Write($"                       i+)IIITI+:+i)I))T"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("LLTTTTII))=,                ");
            Console.SetCursorPosition(23, 22);
            Console.Write($"                        i,i++::i))I)ITT"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("TTTTIIII)=+'                ");
            Console.SetCursorPosition(23, 23);
            Console.Write($"                          ::=i)))iIITTT"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&&&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("TTIIIII)=+                      ");
            Console.SetCursorPosition(23, 24);
            Console.Write($"                            )i)iIIIITII"); Console.ForegroundColor = ConsoleColor.Green; Console.Write("&"); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("TIIII))i+:'                        ");
            Console.SetCursorPosition(23, 25);
            Console.Write($"                               `:i)))IIIII)ii+'         ");
            Console.SetCursorPosition(23, 26);
            Console.Write($"                                                                        ");
            Console.SetCursorPosition(23, 27);
            Console.Write($"                                                                        ");
            Console.SetCursorPosition(23, 28);
            Console.Write("                                                                        ");
            Console.ForegroundColor = ConsoleColor.Blue;
            ClearInputViewer();
            Console.SetCursorPosition(24, 37);
            Console.Write("Welcome To Earth!  Please proceed to the mineral depot to sell your goods.");
            Console.SetCursorPosition(24, 39);
            Console.Write("We also offer a wide range of ship upgrades available in the ship upgrade ");
            Console.SetCursorPosition(24, 40);
            Console.Write("facility!  We have scanners that increase your chance of finding specific");
            Console.SetCursorPosition(24, 41);
            Console.Write("minerals, mining lasers that increase mining returns, and general weapons");
            Console.SetCursorPosition(24, 42);
            Console.Write("upgrades!  Press <ENTER> to land...");
            Console.ReadKey();
        }

    }
}