﻿using System;

namespace SpaceGame
{
    public class Planets
    {
        //Set planet name
        public string name { get; set; }
        //Set copper value 
        public int copperValue { get; set; }
        //Set diamond value
        public int diamondValue { get; set; }
        //Set gold value
        public int goldValue { get; set; }
        //Set iron ore value
        public int ironValue { get; set; }
        //Set platinum value
        public int platinumValue { get; set; }
    }

    public class Venus : Planets
    {
        public Venus()
        {
            name = "Venus";
            copperValue = 43;
            diamondValue = 52;
            goldValue = 29;
            ironValue = 20;
            platinumValue = 70;
        }
    }

    public class Mars : Planets
    {
        public Mars()
        {
            name = "Mars";
            copperValue = 52;
            diamondValue = 90;
            goldValue = 57;
            ironValue = 20;
            platinumValue = 80;
        }
    }

    public class Earth : Planets
    {
        public Earth()
        {
            name = "Earth";
            copperValue = 29;
            diamondValue = 150;
            goldValue = 60;
            ironValue = 20;
            platinumValue = 83;
        }
    }

    public class Mercury : Planets
    {
        public Mercury()
        {
            name = "Mercury";
            copperValue = 40;
            diamondValue = 97;
            goldValue = 50;
            ironValue = 20;
            platinumValue = 74;
        }
    }

    public class Pluto : Planets
    { 
        public Pluto()
        {
            name = "Pluto";
            copperValue = 33;
            diamondValue = 123;
            goldValue = 61;
            ironValue = 20;
            platinumValue = 95;
        }
    }
}