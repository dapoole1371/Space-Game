﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SpaceGame
{
    public class Enemies
    {
        //Set enemy name
        public string name { get; set; }
        //Set enemy attack power
        public int attackPower { get; set; }
        //Set enemy hp
        public int hp { get; set; }
        //Set enemy credits
        public int credits { get; set; }

        public int HPGenerator()
        {
            Random rand = new Random();
            int randomHPValue = rand.Next(35, 75);
            return randomHPValue;
        }

        public int AttackGenerator()
        {
            Random rand = new Random();
            int randomAttackValue = rand.Next(15, 25);
            return randomAttackValue;
        }

        public int CreditsGenerator()
        {
            Random rand = new Random();
            int randomCredits = rand.Next(600, 850);
            return randomCredits;
        }

        public Enemies()
        {
            name = "Generic";
            attackPower = 1;
            hp = 1;
            credits = 50;
        }
    }
    //Created by Alan
    public class Sith : Enemies
    {
        public Sith()
        {
            this.name = "Sith";
        }
    }
    //Created by Joe
    public class Pirates : Enemies
    {
        public Pirates()
        {
            this.name = "Pirate";
        }
    }
    //Definitely created by Taylor and ONLY Taylor
    public class Lenore : Enemies
    {
        public Lenore()
        {
            this.name = "Lenore the Programming Master";
            this.attackPower = 99;
            this.hp = 100;
            this.credits = 10000;
        }
    }
    //Created by Dave
    public class Romulan : Enemies
    {
        public Romulan()
        {
            this.name = "Romulan";
        }
    }

    public class GrayAlien : Enemies
    {
        public GrayAlien()
        {
            this.name = "Gray";
        }
    }

}