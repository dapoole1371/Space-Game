﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SpaceGame
{
    public class Player
    {
        //Sets initial values for a player
        public string playerType { get; set; }
        public int playerEmptyCargoSpace { get; set; }
        public int playerCredits { get; set; }

        //Sets the level of ship components
        public int playerWeaponLevel { get; set; }
        public int playerScannerLevel { get; set; }
        public int playerMiningLaserLevel { get; set; }
        public int shipDurability { get; set; }
        public int shipMaxDurability { get; set; }

        //Sets the amount of cargo in ship
        public int playerCopper { get; set; }
        public int playerDiamonds { get; set; }
        public int playerGold { get; set; }
        public int playerIronOre { get; set; }
        public int playerPlatinum { get; set; }
        public int playerCargo { get; set; }
        public int playerShipCargoSpace { get; set; }

        //Set a player name from selection
        public static void PlayerTypeSet(Player player, Menus main)
        {
            int userTypeSelection = main.CharacterSelectionDisplay(player);
            switch ((PlayerTypes)userTypeSelection)
            {
                case PlayerTypes.Trader:
                    player.playerType = new Trader().playerType;
                    player.playerCredits = new Trader().playerCredits;
                    player.playerWeaponLevel = new Trader().playerWeaponLevel;
                    player.playerShipCargoSpace = new Trader().playerShipCargoSpace;
                    player.playerEmptyCargoSpace = new Trader().playerEmptyCargoSpace;
                    main.ClearMainViewer();
                    break;
                case PlayerTypes.Entrepreneur:
                    player.playerType = new Entrepeneur().playerType;
                    player.playerCredits = new Entrepeneur().playerCredits;
                    player.playerWeaponLevel = new Entrepeneur().playerWeaponLevel;
                    player.playerShipCargoSpace = new Entrepeneur().playerShipCargoSpace;
                    player.playerEmptyCargoSpace = new Entrepeneur().playerEmptyCargoSpace;
                    main.ClearMainViewer();
                    break;
                case PlayerTypes.BountyHunter:
                    player.playerType = new BountyHunter().playerType;
                    player.playerCredits = new BountyHunter().playerCredits;
                    player.playerWeaponLevel = new BountyHunter().playerWeaponLevel;
                    player.playerShipCargoSpace = new BountyHunter().playerShipCargoSpace;
                    player.playerEmptyCargoSpace = new BountyHunter().playerEmptyCargoSpace;
                    main.ClearMainViewer();
                    break;
                case PlayerTypes.Miner:
                    player.playerType = new Miner().playerType;
                    player.playerCredits = new Miner().playerCredits;
                    player.playerWeaponLevel = new Miner().playerWeaponLevel;
                    player.playerShipCargoSpace = new Miner().playerShipCargoSpace;
                    player.playerScannerLevel = new Miner().playerScannerLevel;
                    player.playerEmptyCargoSpace = new Miner().playerEmptyCargoSpace;
                    main.ClearMainViewer();
                    break;
                default:
                    break;
            }
        }

        public Player()
        {
            playerType = "Generic";
            playerCopper = 0;
            playerGold = 0;
            playerPlatinum = 0;
            playerDiamonds = 0;
            playerIronOre = 0;
            playerCargo = 0;
            playerShipCargoSpace = 0;
            playerEmptyCargoSpace = 0;
            playerCredits = 0;
            playerScannerLevel = 0;
            playerMiningLaserLevel = 0;
            playerWeaponLevel = 0;
            shipDurability = 200;
            shipMaxDurability = 200;
        }

        public int InputValidation(string input, int min, int max)
        {
            int validatedNum;
            while (!int.TryParse(input, out validatedNum) || validatedNum > max || validatedNum < min)
            {
                Console.SetCursorPosition(24, 39);
                Console.Write("                             ");
                Console.SetCursorPosition(24, 39);
                Console.Write("Invalid selection. Try again.");
                input = Console.ReadLine();
            }
            return validatedNum;
        }
    }
    public class Trader : Player
    {
        public Trader()
        {
            this.playerCredits = 5000;
            this.playerShipCargoSpace = 20;
            this.playerEmptyCargoSpace = 20;
            this.playerWeaponLevel = 1;
            this.playerType = "Trader";
        }
    }
    public class Entrepeneur : Player
    {
        public Entrepeneur()
        {
            this.playerCredits = 10000;
            this.playerShipCargoSpace = 5;
            this.playerEmptyCargoSpace = 5;
            this.playerWeaponLevel = 1;
            this.playerScannerLevel = 1;
            this.playerType = "Entrepeneur";

        }
    }
    public class BountyHunter : Player
    {
        public BountyHunter()
        {
            this.playerCredits = 7500;
            this.playerShipCargoSpace = 15;
            this.playerEmptyCargoSpace = 15;
            this.playerWeaponLevel = 2;
            this.playerScannerLevel = 1;
            this.playerType = "Bounty Hunter";
        }
    }
    public class Miner : Player
    {
        public Miner()
        {
            this.playerCredits = 1000;
            this.playerShipCargoSpace = 30;
            this.playerEmptyCargoSpace = 30;
            this.playerWeaponLevel = 1;
            this.playerScannerLevel = 10;
            this.playerType = "Miner";
        }
    }

}