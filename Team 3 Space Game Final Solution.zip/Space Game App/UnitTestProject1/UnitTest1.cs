using Microsoft.VisualStudio.TestTools.UnitTesting;
using SpaceGame;
namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMainMenu()
        {
            //Menus main = new Menus();
            //var results = main.MainMenu(player, main);
            //Assert.AreEqual("1. Travel to a planet. \n2. Mine in the asteroid belt.\n3. Battle final boss", results);
        }
    }
}
